$(document).ready(function(){
	initHandler();

	return false;
});

var initHandler = function(){
	//inputFocusedHandler(); // 인풋 포커스 일때 focused 클래스 추가
	//secureClickHandler(); // 키패드 띄우기 위한 체크박스 클릭시
	// inputDeleteHandler(); // 인풋 안에 delete버튼 뜨도록 함
	// expandHandler(); // 확장 축소 버튼
	// accountExpandHandler(); // 자주쓰는 펼쳐보기
	// securityCardHandler(); // 보안카드
	// clickRemoveHandler(); // 바닥 클릭시 요소 사라지게 하기
	// listTooltipHandler(); // 리스트 툴팁
	// reservationHandler(); // 예약이체 체크
	// calendarAllGroupHandler(); // 캘린더 조회
	// moveScrollHandler(); // 이체 입금계좌 선택시 스크롤 이동
	// globalNavHandler(); // GNB
	// sortingBtnHandler(); // 테이블 외부 sorting 버튼
	// sortingBtnHandler2(); // 테이블 내부 sorting 버튼
	// multipleBtnHandler(); // 다중 버튼 (캘린더, 금액선택)
	// searchBtnHandler(); // 조회 인풋 활성화 버튼
	// inqySsetupBox();  // 조회 설정
	// viewtypeBtnHandler();  // 카드형/리스트형 버튼
	// viewtypeHandler();  // 카드형/리스트형 
	// triggerTableHandler(); //  솔팅 테이블 공통
	// familysiteHandler(); // ui셀렉트 - 패밀리사이트
	// CustomSelectBoxInit();  // ui셀렉트
	// editBtnHandler(); // 금액수정/수정취소 버튼
	// bankCheckList(); // 뱅크체크리스트 - 이체폼
	// fileDropBtn(); // 파일등록 - 버튼
	calendarAllGroupHandler(); // 캘린더 조회
	SwiperModule(); // 스와이퍼 모음
	// checkAllHandler(); // 전체동의
	numberOnlyHandler();  // 넘버(texts)
	tabHandler(); // 탭
	setTimeout(function(){accordionHandler();},100); // 아코디언
	switchBtn(); // 솔팅버튼
	inputValue(); // 인풋박스 - 삭제버튼
	btnUnit(); // 인풋박스 - 단위 유형 케이스
	btnAccount_type02(); // 인풋박스 - 바텀시트 - 은행인풋 케이스
	btnFavorite(); // 즐겨찾기 별 아이콘
	btnMore(); // 정보박스 더보기 버튼
	quickMenu(); // 퀵메뉴
	tooltipHandler(); //툴팁
	tranBtn(); //예약이체버튼
	areaEvent(); // 예적금 - 상품가입 지역 검색 스크립트
	apprEvent(); // 결재선 - 이벤트
	apprGuideSlideHandler(); //승인결재이용안내 슬라이드
	return false;
}

var winW = 0, winH = 0;
var locY = 0;

// GNB
var globalNavHandler = function() {
	$('.header-bot .gnb > li > a').on('mouseover focus', function(){
		$('.header-bot .gnb > li').removeClass('focused');
		$('.submenu').hide();	
		$('.header-bot').find('.submenu-bg').hide();
		$(this).parent().addClass('focused');
		if($(this).parent().hasClass('focused')){
			$(this).siblings('.submenu').show();
			var thisHeight = $(this).siblings('.submenu').height();
			$(this).parents('.header-bot').find('.submenu-bg').show();
			$(this).parents('.header-bot').find('.submenu-bg').css({'height':thisHeight, 'box-shadow':'0px 4px 4px 0px rgba(0,0,0,0.1)'});
			$(this).siblings('.submenu').css({'height' :thisHeight});
		};
	});

	$('.header-bot .gnb > li').on('mouseleave', function(){
		$(this).removeClass('focused');
		$(this).find('.submenu-bg').hide();
		$('.header-bot').find('.submenu-bg').hide();
		if($(this).siblings('li').hasClass('.focused')){
			$(this).siblings('.submenu').show();
			$(this).parents('.header-bot').find('.submenu-bg').show();
			$(this).parents('.header-bot').find('.submenu-bg').css({'height':thisHeight, 'box-shadow':'0px 4px 4px 0px rgba(0,0,0,0.1)'});
			$(this).siblings('.submenu').css({'height' :thisHeight});
		}
	});
};

// 리스트 툴팁 열기
var listTooltipHandler = function(){
	$(document).ready(function(){
		//layer tooltip 
		var layerWraps = $('.layerView').parent().parent();
		var layerWrapsList = $('.layerView').parent().parent().find('div.layerListWrap');
		$('.layerView').each(function(i){
			$(this).click(function(){
				for(var x=0; x<layerWrapsList.length; x++)
				{
					if(x != i)
					{
						layerWrapsList.eq(x).hide();
						layerWraps.eq(x).css({
							position : 'static'
						});
					}
				}
	
				var $eleParent = $(this).parent().parent();
				$eleParent.css({
					'position' : 'relative',
					'zIndex' : '10',
					'width' : '100%'
				});
				var pLeft = $(this).position().left;
				var pTop = $(this).position().top;
				var $linkWidth = $(this).outerWidth();
				var $accountList = $eleParent.find('div.layerListWrap');
				var eleWidth = $accountList.outerWidth();
				var eleHeight = $accountList.outerHeight();
				
				$accountList.css({
					'left' : pLeft - eleWidth + $linkWidth,
					top : pTop + 28,
					width : eleWidth,
					height : eleHeight
				});
				$accountList.find('span.arrow').css('right', '10px');
	
				if( $accountList.is(':hidden') )
				{
					$accountList.show();
					if(navigator.appVersion.indexOf("6.0") != -1)
					{
						$accountList.prepend('<!--[if lte IE 6]><iframe id="iframe" style="width:' + eleWidth + '; height:' + eleHeight + ';"></iframe><![endif]-->')
					}
				}
				else
				{
					if( $accountList.find('iframe').length > 0 )
					{
						$accountList.find('iframe').remove();
					}
					$accountList.hide();
				}
				return false;
			});
		});
	});
}

// 리스트 툴팁 닫기
function layerClose3(eleThis){
	var element = eleThis;
	$(element).parent().hide();

	//Layer 호출 버튼으로 포커스 이동
	// $(element).parent().parent().parent().find('span').find('.layerView').focus();
	// if( $(element).parent().parent().find('iframe').length > 0 ){
	// 	$(element).parent().parent().find('iframe').remove();}
}


// 새창열림 팝업
function openPopupWindow(url, name) {
	var options='width=500, height=600, top=30, left=30, resizable=no, scrollbars=no, location=no';
	window.open(url,name,options);
}


// 인풋 안에 delete버튼 뜨도록 함
var inputDeleteHandler = function() {
	$(document).on('keyup keydown', 'input[type=text], input[type=number], input[type=password], input[type=search]', function(e){
		if(e.type=="keyup"){
			if(!$(this).attr('readonly') && $(this).val().length && $(this).next('.btn.delete').length){
				$(this).next('.btn.delete').addClass('active');
				$(this).next('.btn.delete').attr('tabindex','-1');
			}else{
				$(this).next('.btn.delete').removeClass('active');
			}
			if($(this).hasClass('money') && $(this).val().length && $(this).next().next('.btn.delete').length){
				$(this).next().next('.btn.delete').addClass('active');
			}else{
				$(this).next().next('.btn.delete').removeClass('active');
			}
		} else if(e.type=="keydown"){
			$(this).next('.btn.delete').attr('tabindex','-1');
		}
	});


	$(document).on('click mousedown mouseleav', '.btn.delete', function(e){
		var _this=$(this);
		if(e.type=='click'){
			if(!_this.prev('input').attr('readonly')){
				_this.removeClass('active');
				_this.prev('input').val('').focus();
			}
			if(_this.prev().prev('input').hasClass('money')){
				_this.removeClass('active');
				_this.prev().prev('input').val('').focus();
			}
			if(_this.prev('input').data('web-e2e-keypad-type')){
				clearE2E(_this.prev('input').attr('id'));
				_this.removeClass('active');
				_this.prev('input').val('').focus();
	 		}
		}
	});
};

// 키패드 띄우기 위한 체크박스 클릭시
var secureClickHandler = function() {
	// .keypad1
	$(document).on('click', '.secure-group input[type=checkbox]', function(){
		var _this = $(this);
		var val = $(this).prop('checked');
		if(val){
			if($('.keypad1').length && $('.keypad1').css('display')=='block'){
				$('.keypad1').focus();
			}
		}
	});
}

// 확장 축소 버튼
var expandHandler = function() {
	$(document).on('click', '.btn.expand', function(e){
		if(!$(this).attr('disabled')){
			if($(this).attr('aria-expanded')=='false') {
				$(this).attr('aria-expanded', 'true');
				$(this).find('.ui-text').text('닫기');
				$(this).addClass('active');
			}else{
				$(this).attr('aria-expanded', 'false');
				$(this).find('.ui-text').text('더 보기');
				$(this).removeClass('active');
			}
		}
	});
};

// 툴팁
var tooltipHandler = function(){
	if($('.btn.tooltip').length){
		$('.btn.tooltip').attr('aria-expanded','false').parent().next('.tooltip-info').attr('aria-hidden','true');
	}
	$(document).off('click', '.btn.tooltip').on('click', '.btn.tooltip', function(){
		if($(this).attr('aria-expanded')=='true') {
			$(this).removeClass('active').attr('aria-label','툴팁레이어 열기').attr('aria-expanded','false');
			$(this).closest('.tooltip-box').removeClass('active').find('.tooltip-info').attr('aria-hidden','true').removeClass('active').hide();
			$(this).closest(".ui-contents").removeAttr('style');
		}else {
			$(".tooltip-box.active").removeClass('active')
			$(".btn.tooltip").removeClass('active').attr('aria-label','툴팁레이어 열기').attr('aria-expanded','false');
			$('.tooltip-info').attr('aria-hidden','true').removeClass('active').hide();
			$(this).addClass('active').attr('aria-label','툴팁레이어 닫기').attr('aria-expanded','true');
			$(this).closest('.tooltip-box').addClass('active').find('.tooltip-info').attr('aria-hidden','false').addClass('active').show();
			
			// 툴팁 하단에 있을시 높이 처리
			var tip_Height = $(this).closest(".tooltip-box").find(".tooltip-info.active").innerHeight();
			var tip_offset = $(this).closest(".tooltip-box").find(".tooltip-info.active").offset().top;
			var ui_height = $(".ui-contents").height();
			var ui_innerHeight = $(".ui-contents").innerHeight();
			var header_innerHeight = $(".ui-header").innerHeight();
			if(ui_height < tip_offset){
				$(this).closest(".ui-contents").css('padding-bottom',ui_innerHeight - ui_height - header_innerHeight + tip_Height);
				$("html,body").animate({scrollTop:ui_innerHeight},300)
			}
		}
	})
	$(document).off('click', '.tooltip-box .btn.close').on('click', '.tooltip-box .btn.close', function(e){
		$(this).closest('.tooltip-info').removeClass('active').attr('aria-hidden','true').hide();
		$(this).closest('.tooltip-box').find('.btn.tooltip').attr('aria-label','툴팁레이어 열기').attr('aria-expanded','false').focus();
		$(this).closest(".ui-contents").removeAttr('style');
	});
};


// 탭
var tabHandler = function(){
	if($('.tab-group').length){
		/*
		var lists=$('.tab-group').find('.tab-heading li');
		
		for(var a=0; a<lists.length;a++){
			var list = lists.eq(a);
			list.attr('tabindex','0')
			if(list.text().length==2) {
				list.css('width','40px');
			}else if(list.text().length==3) {
				list.css('width','55px');
			}else if(list.text().length==4) {
				if(a==0){
					list.css('width','65px');
				}else{
					list.css('width','70px');
				}
			}
		}
		*/
		// var tabSlide = '.tab-group[data-tab-slide] > .tab-heading-wrap > .tab-heading > li'
		var tabMenu = '.tab-group[data-tab] > .tab-heading-wrap > .tab-heading > li a'

		$(document).on('click',tabMenu, function(){
			var con = $(this).parents('.tab-heading-wrap').next('.tab-body');
			var heading = $(this).parents('.tab-heading');
			var idx = $(this).parent().index();
			var tabSlide = $(this).closest("[data-tab-slide]");
			heading.find('li').removeClass('on').children().attr('aria-selected','false')
			heading.find('li').eq(idx).addClass('on').children().attr('aria-selected','true');
			
			if(con.length){
				con.find('.tab-con').css('display', 'none').attr('aria-hidden','true');
				con.find('.tab-con').eq(idx).css('display', 'block').attr('aria-hidden','false');
				$(window).trigger('resize');
				SwiperModule();
			}
			// accordionHandler();
			// SwiperModule();
			
			return false;
		});
		$(document).off('keyup', '.tab-group > .tab-heading-wrap > .tab-heading li').on('.tab-group > .tab-heading-wrap > .tab-heading li', function(e){
			// 엔터
			if(e.keyCode=='13') { 
				$(this).trigger('click');
			}

		});
	}
};

// 아코디언
var accordionHandler = function() {
	// if($('.accordion-group').not('.no-toggle').length){
	// 	$(document).off('click', '.accordion-group .acc-expand').on('click', '.accordion-group .acc-expand', function(e){
	// 		var accGroup = $(this).parent().parent('.accordion-group');
	// 		var accBody = $(this).parent().next('.acc-body');
	// 		var headingHeight = $(this).parent().innerHeight();
	// 		if($(this).attr('aria-expanded')=='true' && $(this).hasClass('active')){
	// 			$(this).attr('aria-expanded','false');
	// 			$(this).children('.ui-blind').text('더보기');
	// 			accBody.attr('aria-hidden','true');
	// 			$(this).removeClass('active');
	// 			TweenMax.to(accGroup, 0.5, {height:headingHeight, ease:Power4.easeOut, onUpdate:function(){
	// 				$(window).trigger('resize');
	// 			}});
	// 		}else if($(this).attr('aria-expanded')=='false' && !$(this).hasClass('active')){
	// 			$(this).attr('aria-expanded','true');
	// 			$(this).children('.ui-blind').text('닫기');
	// 			$(this).addClass('active');
	// 			accBody.attr('aria-hidden','false');
	// 			accBody.addClass('active');
	// 			TweenMax.to(accGroup, 0.5, {height:accGroup.attr('data-height'), ease:Power4.easeOut, onUpdate:function(){
	// 				$(window).trigger('resize');
	// 			}});
	// 		}else if($(this).attr('aria-expanded')=='true' && !$(this).hasClass('active')){
	// 			$(this).attr('aria-expanded','false');
	// 			$(this).removeClass('active');
	// 			accBody.attr('aria-hidden','true');
	// 			TweenMax.to(accGroup, 0.5, {height:0, ease:Power4.easeOut, onUpdate:function(){
	// 				$(window).trigger('resize');
	// 			}});
	// 		}
	// 	});
		
	// 	for(var a=0; a<$('.accordion-group').length; a++){
	// 		var acc = $('.accordion-group').eq(a);
	// 		var target = accTitle=='유의사항'?$('.accordion-group').eq(a).find('.acc-expand'):null;
	// 		var accHeaderH = acc.find('.acc-heading').innerHeight();
	// 		var accBody = acc.find('.acc-body');
	// 		var accBodyH = acc.find('.acc-body').innerHeight();
	// 		var accTitle = $('.accordion-group').eq(a).find('.tit').text();
	// 		acc.find('.btn.acc-expand').attr('title',accTitle);
	// 		acc.attr('data-height', (accHeaderH + accBodyH));
	// 		// .acc-expand 에 active 가 없을 시 닫힘 처리
	// 		if(acc.find('.acc-expand').attr('aria-expanded')=='true' && acc.find('.acc-expand').hasClass('active')){
	// 			accBody.addClass('active');
	// 		}
	// 		if(acc.find('.acc-expand').attr('aria-expanded')=='false' && !acc.find('.acc-expand').hasClass('active')){
	// 			acc.css('height', accHeaderH+'px');
	// 			accBody.css('aria-hidden','true');
	// 		}
	// 		if(target!=null){
	// 			accBody.addClass('active');
	// 			target.removeClass('active').attr('aria-expanded','false').attr('title', '유의사항');
	// 			acc.css('height', accHeaderH+'px');
	// 			accBody.css('aria-hidden','true');
	// 		}
	// 	}
	// }
	// if($('.accordion-group.no-toggle').length){
	// 	$('.accordion-group.no-toggle').removeAttr('style');
	// }

	// $(document).off('click', ".accordion-wrap .accordion-header .btn.accordion").on('click', ".accordion-wrap .accordion-header .btn.accordion", function(e){
	// 	if($(this).hasClass("active")){
	// 		$(this).removeClass("active").attr("aria-expanded","false").parents(".accordion-wrap").removeClass("active").children(".accordion-content").hide().attr("aria-hidden","true");
	// 		$(this).children(".text-acc.active").removeClass("active").next(".text-acc").addClass("active");
	// 	}else{
	// 		$(this).addClass("active").attr("aria-expanded","true").parents(".accordion-wrap").addClass("active").children(".accordion-content").show().attr("aria-hidden","false");
	// 		$(this).children(".text-acc.active").removeClass("active").prev(".text-acc").addClass("active");
	// 	}
	// })

	
	var accWrap = "[data-acc-wrap]"
	var accBtn = "[data-acc-wrap] [data-acc-btn]"
	var accCont = "[data-acc-cont]"

	$(document).off('click',accBtn).on("click",accBtn,function(){
		if($(this).hasClass("active")){
			$(this).removeClass("active").attr("aria-expanded","false").parents(accWrap).removeClass("active").find(accCont).hide().attr("aria-hidden","true");
			$(this).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active");
		}else{
			$(this).addClass("active").attr("aria-expanded","true").parents(accWrap).addClass("active").find(accCont).show().attr("aria-hidden","false");
			$(this).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active");
		}
		$(this).closest(".swiper-wrapper").css({"height":"auto"});

	})

	$("[data-acc-list-wrap]").each(function(index,item){
		var accOnlyMark = $("[data-acc-list-wrap]").find("[data-acc-list-only]")
		var accMark = $("[data-acc-list-wrap]").find("[data-acc-list-mark]")
		var itemList = $(item).find("[data-acc-list]")
		var itemBtn = $(item).find("[data-acc-list-btn]")
		if($(item).hasClass("active")){
			accMark.nextAll().show();
			accOnlyMark.siblings().show();
			accOnlyMark.parent().siblings().show();
			itemBtn.parent().show();
			if(itemList.attr("class") == itemList.next().attr("class")){
				itemList.nextAll("."+itemList.attr("class")).show();
			}
		}else{
			accMark.nextAll().hide().filter(".btn-wrap").children(itemBtn).parent().show();
			accOnlyMark.siblings().hide();
			accOnlyMark.parent().css({"margin":"0"}).siblings().hide();
			if(itemList.attr("class") == itemList.next().attr("class")){
				itemList.nextAll("."+itemList.attr("class")).hide();
			}
		}
		// if($(item).hasClass("accordion-wrap type03")){
		// 	if($(item).find("[data-acc-list] .list-item").length == 1){
				
		// 	}
		// }
	})


	var accListBtn = "[data-acc-list-wrap] [data-acc-list-btn]"

	$(document).off('click',accListBtn).on('click', accListBtn, function(){
		var accordionWrap = $("[data-acc-list-wrap]");
		var accList = $(this).closest("[data-acc-list-wrap]").find("[data-acc-list]")
		var accMark = $(this).closest("[data-acc-list-wrap]").find("[data-acc-list-mark]")
		var accOnlyMark = $(this).closest("[data-acc-list-wrap]").find("[data-acc-list-only]")
		var accOnlyPrev = accOnlyMark.parent().prev().css("margin-top")
		var accOnlyNext = accOnlyMark.parent().next().css("margin-top")
		if($(this).hasClass("active")){
			$(this).removeClass("active").attr("aria-expanded","false").closest(accordionWrap).removeClass("active");
			$(this).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active")
			accMark.nextAll().hide().filter(".btn-wrap").children($(this)).parent().show();
			accOnlyMark.siblings().hide();
			accOnlyMark.parent().css({"margin-top":"0"}).siblings().hide();
			if(accList.attr("class") == accList.next().attr("class")){
				accList.nextAll("."+accList.attr("class")).hide();
			}
		}else{
			$(this).addClass("active").attr("aria-expanded","true").closest(accordionWrap).addClass("active");
			$(this).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active")
			accMark.nextAll().show();
			accOnlyMark.siblings().show();
			if(accList.attr("class") == accList.next().attr("class")){
				accList.nextAll("."+accList.attr("class")).show();
			}
			if(accOnlyMark.parent().index() == 0){
				accOnlyMark.parent().css({"margin-top":accOnlyNext}).siblings().show();
			}else{
				accOnlyMark.parent().css({"margin-top":accOnlyPrev}).siblings().show();
			}
		}
	})
	
};

// 자주쓰는 펼쳐보기
var accountExpandHandler = function(){
	if($('.result-group').length) {
		$('.result-group').find('.btn.expand').on('click', function(){
			var rstGroupH=0;
			if($(this).closest('.result-group').find('.tab-con-inner').attr('data-minimum')==undefined){
				rstGroupH = parseInt($(this).closest('.result-group').find('.tab-con-inner').css('min-height'));
				$('.result-group').find('.tab-con-inner').attr('data-minimum', rstGroupH);
			}
			if($(this).attr('aria-expanded')=='false') {
				$(this).parent().parent().prev('.tab-con-body').find('.tab-con-inner').animate({'max-height':328},300,function(){
					$(window).trigger('resize');		
				});
			}else{
				$(this).parent().parent().prev('.tab-con-body').find('.tab-con-inner').animate({'max-height':rstGroupH},300,function(){
					$(window).trigger('resize');
				});
			}
		});
	}
	if($('.tab-result-group').length) {		// 팝업 속 탭 내 펼쳐보기
		$('.tab-result-group').find('.btn.expand').on('click', function(){
			var rstGroupH=0;
			if($(this).closest('.tab-result-group').find('.tab-con-inner').attr('data-minimum')==undefined){
				rstGroupH = parseInt($(this).closest('.tab-result-group').find('.tab-con-inner').css('min-height'));
				$('.tab-result-group').find('.tab-con-inner').attr('data-minimum', rstGroupH);
			}
			if($(this).attr('aria-expanded')=='false') {
				$(this).parent().parent().prev('.tab-con-body').find('.tab-con-inner').animate({'max-height':400},300,function(){
					$(window).trigger('resize');
				});
			}else{
				$(this).parent().parent().prev('.tab-con-body').find('.tab-con-inner').animate({'max-height':rstGroupH},300,function(){
					$(window).trigger('resize');
				});
			}
		}); 
	}
	if($('.addr-group .result-group').length) {
		$('.addr-group').find('.btn.expand').on('click', function(){
			if($(this).attr('aria-expanded')=='false') {
				$(this).parent().prev('.result-group').animate({'max-height':400},300,function(){
					$(window).trigger('resize');
				});
			}else{
				$(this).parent().prev('.result-group').animate({'max-height':205},300,function(){
					$(window).trigger('resize');
				});
			}
		});
	}
	if($('.sorting-group .country-list').length) {
		$('.sorting-group').find('.btn.expand').on('click', function(){
			if($(this).attr('aria-expanded')=='false') {
				$(this).parent().parent().find('.country-list').animate({'max-height':300},300,function(){
					$(window).trigger('resize');
				});
			}else{
				$(this).parent().parent().find('.country-list').animate({'max-height':124},300,function(){
					$(window).trigger('resize');
				});
			}
		});
	}	
};

// 보안카드
var securityCardHandler = function() {
	if($('.security-group .left-card').length && $('.security-group .right-card').length){
		for(var a=0; a<$('.security-group').length; a++){
			var scGroup = $('.security-group').eq(a);
			var rightCard = scGroup.find('.right-card');
			var leftNum = parseFloat(rightCard.find('.left-num').text());
			var rightNum = parseFloat(rightCard.find('.right-num').text());
			var leftLocXNum = Math.ceil(leftNum/7)-1;
			var leftLocYNum = (leftNum-1)%7;
			var rightLocXNum = Math.ceil(rightNum/7)-1;
			var rightLocYNum = (rightNum-1)%7;
			var xGap = 58.4;
			var yGap = 22;
			scGroup.find('.left-card .box-left-area').css({left:(leftLocXNum*xGap + 24), top:yGap*leftLocYNum +5});
			scGroup.find('.left-card .box-right-area').css({left:(rightLocXNum*xGap + 24), top:yGap*rightLocYNum+5});
		}
	}
	if($('.seq-num-box').length && $('.seqserial-group').length){
		var arrOfNum = [];
		var total = $('.seqserial-group > *').length;
		var count=-1;
		for(var a=0; a<total; a++){
			if($('.seqserial-group > *').eq(a).hasClass('serial')){
				count++;
				$('.seqserial-group > *').eq(a).attr('data-idx',count);
				arrOfNum.push(a-1);
			}
		}
		for(var a=0; a<arrOfNum.length; a++){
			$('.seq-num-box .box-top-area').eq(a).css('left', 14*arrOfNum[a]);
		}
	}

	if($('.seqserial-group').length){
		$('.seqserial-group input').off('keyup').on('keyup', function(e){
			var idx = parseInt($(this).attr('data-idx'));
			if($('.security-group').length){
				if($(this).val().length){
					$(this).closest('.right-card').prev('.left-card').find('.seq-num-box .seq-box').eq(idx).text('*');
				}else{
					$(this).closest('.right-card').prev('.left-card').find('.seq-num-box .seq-box').eq(idx).text('');
				}
			}
		});
	}
	if($('.security-group .left-card').length && $('.security-group .right-card').length) {
		for(var a=0; a<$('.security-group .right-card').length; a++){
			for(var b=0; b<$('.security-group .right-card').eq(a).find('.seqcard-group').length;b++){
				$('.security-group .right-card').eq(a).find('.seqcard-group').eq(b).find('input.default.secure').attr('data-idx',b);
				$('.security-group .right-card').eq(a).find('.seqcard-group').eq(b).find('input.default.secure').on('keyup', function(e){
					var textLen = $(this).val().length;
					$(this).closest('.right-card').prev('.left-card').find('.seq-box-group .seq-box').eq(parseInt($(this).attr('data-idx'))).text('');
					var str = '';
					for(var c=0;c<textLen;c++){
						str +='*' ;
					}
					$(this).closest('.right-card').prev('.left-card').find('.seq-box-group .seq-box').eq(parseInt($(this).attr('data-idx'))).text(str);
				});
			}
		}
		$('.security-group .right-card input.default.secure').off('click').on('click', function(){
			if($(this).prop('checked')){
				$(this).closest('.right-card').prev('.left-card').find('.seq-box').text('');
				$(this).closest('.right-card').find('input').val('');
			}
		});
	}
};

// 바닥 클릭시 요소 사라지게 하기
var clickRemoveHandler = function() {
	$(document).on('mouseup', function(e){
		var target = $(e.target);
		// 캘린더 있을 경우, 캘린더 이외 클릭하면 캘린더 사라지게 하기
		if(!target.closest('.datepicker-calendar').length){
			if($('.datepicker-calendar').not('.views').css('display')=='block'){
				$('.datepicker-calendar').not('.views').find('.datepicker-close').trigger('click');
			}
		}
		// header 메뉴 검색 결과창 있을경우, 이외 클릭시 사라지게 하기
		// if(!target.closest('.gnb-search-menu').length){
		// 	$('.gnb-search-area').removeClass('focused');
		// }

	});
};

// 전체동의
var checkAllHandler = function(){

	var checkBoxWrap = $("[data-checkBox-wrap]")
	var checkBoxAll = $("[data-checkBox-all]")
	var checkBoxList = $("[data-checkBox-list]")
	var checkBoxItem = $("[data-checkBox-item]")
	var accWrap = "[data-checkBox-wrap][data-acc-wrap]"
	var accBtn = "[data-checkBox-wrap][data-acc-wrap] [data-acc-btn]"
	var accCont = "[data-acc-cont]"

	if(checkBoxAll.length || checkBoxList.length){
		checkBoxWrap.find(checkBoxAll).find('input[type=checkbox]').on('click', function(){
			var allCheck = $(this).closest(checkBoxWrap).find(checkBoxList).find('input[type=checkbox]');	
			if($(this).prop('checked')){
				allCheck.prop('checked',true);
			}else{
				allCheck.prop('checked',false);			
			}

			if($(accBtn).hasClass("active")){
				$(accBtn).removeClass("active").attr("aria-expanded","false").closest(accWrap).removeClass("active").find(accCont).hide().attr("aria-hidden","true");
				$(accBtn).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active");
			}else{
				$(accBtn).addClass("active").attr("aria-expanded","true").closest(accWrap).addClass("active").find(accCont).show().attr("aria-hidden","false");
				$(accBtn).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active");
			}
		});

		checkBoxWrap.find(checkBoxList).find('input[type=checkbox]').on('click', function(){
			var checkList = $(this).closest(checkBoxWrap).find(checkBoxAll).find('input[type=checkbox]');
			var isBool = listCheckBool(); 
			if(isBool){
				checkList.prop("checked",true);
				$(accBtn).removeClass("active").attr("aria-expanded","false").closest(accWrap).removeClass("active").find(accCont).hide().attr("aria-hidden","true");
				$(accBtn).children(".text-acc").filter(".active").removeClass("active").siblings(".text-acc").addClass("active");
			}else{
				checkList.prop('checked',false);	
			}
			
		});

		function listCheckBool() {
			var total = checkBoxList.find('input[type=checkbox]').length;
			var count = 0;
			for(var a=0; a<total; a++){ 
				var checkList = checkBoxList.children().eq(a).find('input[type=checkbox]');
				if(checkList.prop('checked')){
					count++;
				}
			}
			return (total==count)?true:false;
		};
		
	}

	// checkBoxWrap.children(checkBoxAll).find('input[type=checkbox]').on('click', function(){
	// 	var allCheck = $(this).closest(checkBoxAll).next(checkBoxList).find('input[type=checkbox]');	
	// 	if($(this).prop("checked")){
	// 		allCheck.prop('checked',true);
	// 	}else{
	// 		allCheck.prop('checked',false);			
	// 	}
		
	// });

	
	// if($('.check-all-group').length || $('.check-list-group').length){
	// 	$('.check-all-group').find('input[type=checkbox]').on('click', function(){
	// 		var checkList = $(this).closest('.check-all-group').next('.check-list-group').find('input[type=checkbox]'); 
	// 		var listGroup = $(this).closest('.check-all-group').next('.check-list-group'); 
	// 		if($(this).prop('checked')){
	// 			checkList.prop('checked',true);
	// 			listGroup.slideUp(200);
	// 		}else{
	// 			checkList.prop('checked',false);	
	// 			listGroup.slideDown(200);
	// 		}
	// 	});

	// 	$('.check-list-group').find('input[type=checkbox]').on('click', function(){
	// 		var allGroupCheck = $(this).closest('.check-list-group').prev('.check-all-group').find('input[type=checkbox]');	
	// 		var listGroup = $(this).closest('.check-list-group'); 
	// 		var isBool = listCheckBool(); 
	// 		if(isBool){
	// 			allGroupCheck.prop('checked',true);
	// 			// listGroup.slideUp(200);
	// 			allGroupCheck.focus();
	// 		}else{
	// 			allGroupCheck.prop('checked',false);
	// 			// listGroup.slideDown(200);
	// 		}
	// 	});

	// 	/* 약관 리스트 체크 했을 때 전체동의 체크 되고 리스트 그룹 닫힘 */
	// 	$('.check-list-group').find('input[type=checkbox]').on('click', function(){
	// 		var listTotal = $(this).closest('.check-list-group').find('input[type=checkbox]').length;
	// 		var listCheckTotal = $(this).closest('.check-list-group').find('input[type=checkbox]:checked').length;
	// 		var CheckListGroup = $(this).closest('.check-list-group');
	// 		var allCheck = CheckListGroup.siblings('.check-all-group').find('input[type=checkbox]');
	// 		if(listTotal == listCheckTotal){
	// 			CheckListGroup.slideUp(200);
	// 			allCheck.attr('checked',true);
	// 		}else{
	// 			CheckListGroup.slideDown(200);
	// 			allCheck.attr('checked',false);
	// 		}
	// 	});
		
	// 	function listCheckBool() {
	// 		var total = $('.check-list-group').find('input[type=checkbox]').length;
	// 		var count = 0;
	// 		for(var a=0; a<total; a++){ 
	// 			var checkList = $('.check-list-group').find('.agree-check-list').eq(a).find('input[type=checkbox]');
	// 			if(checkList.prop('checked')){
	// 				count++;
	// 			}
	// 		}
	// 		return (total==count)?true:false;
	// 	};
	// }
};

// select  div ( 패밀리사이트 )
var familysiteHandler = function(){
	$(document).on('click', '.select-ui-group .btn-select', function(){
		if(!$(this).hasClass('active')){
			$(this).addClass('active');
			$(this).attr('aria-expanded','true');
			$(this).next('.select-ui-group .list-box').addClass('on');
		}else{
			$(this).removeClass('active');
			$(this).attr('aria-expanded','false');
			$(this).next('.select-ui-group .list-box').removeClass('on');
		}
	});
};


// 즐겨찾기
// var timer=null;
// var favorBtn = function(str, el) {
// 	var addPopup = $('.favor-added').css({'display':'flex'});
// 	$('.favor-added').find('.ui-text').text(str);
// 	if(el!=undefined) {
// 		var $el = $(el);
// 		if($el.closest('.tab-group').length){
// 			var elTop = $el.closest('.tab-group').offset().top - $('.favor-added').innerHeight() - 10;
// 			var elLeft = $el.offset().left;
// 			addPopup.css({'left':elLeft, 'top':elTop, 'position':'absolute', 'transform':'translateX(0)'});
// 		}
// 	}
	
// 	$('body').append(addPopup);
// 	if(timer!=null) clearTimeout(timer);
// 	timer = setTimeout(function(){
// 		addPopup.fadeOut(200);
// 		timer=null;
// 	},2000);
// };

// 토스트 팝업
var timer=null;
var toastBtn = function() {
	var toastPopup = $('.ui-toast-popup').css({'display':'flex'});

	if(timer!=null){
		clearTimeout(timer);
	}
	timer = setTimeout(function(){
		toastPopup.fadeOut(200);
		timer=null;
	},2000);
};

// 팝업 호출
var	uiPopup = {
	open: function(targetEL, popupID, divId, callback) {
		
		popID = popupID

		// var This = $(popupID.target)
		// $('#container').after($(popupID));
		// $('#container').append($(popupID));
		$('#content_wrap').children('.container').append($(popupID));
		if(divId != null || divId !=undefined) {withrawScrollHandler(divId);}
		var $targetEL=$(targetEL);
		$('#container').attr('aria-hidden','true'); // 컨텐츠 영역 안읽힘
		if(!$('.ui-popup.notice-popup').length) {
			$('html, body').css({'overflow':'hidden'}); // 스크롤 불가능
			// $('body:not(.unsupport-browser)').css('padding-right','16px');
			// $('.ui-header').css('padding-right','9px');
			$('.ui-footer').css('width','100vw');
			$('.ui-scroll-top').css('left','calc(50% - 8px)');
		}
		var prevPopups = $('.ui-popup.active');
		if(prevPopups.length!=0){
			$('.ui-popup.active').eq(prevPopups.length-1).find('.ui-popup-body').css('overflow-y','hidden');
		}

		// if($(popID).is('.action.active')){
		// 	$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},200, function() {
		// 		popupClose($(popID), targetEL);
		// 	})
		// }else{
		// 	$(popID).addClass('active');
		// 	$(popID).find('> div').focus();
		// 	$(popID).find('.ui-popup-group').removeAttr('tabindex');
		// 	// 인풋 클릭시 히든
		// 	if ($('.ui-popup.action.active').length > 0)  {
		// 		popupClose($('.ui-popup.action'), targetEL);
		// 		$('html, body').css('overflow','hidden');
		// 	}
		// 	if($(popID).hasClass("action")){
		// 		$(popID).find('.ui-popup-group').css("bottom","-100vh").stop().animate({'bottom':0},150);
		// 		// if($(popID).hasClass("action type02")){
		// 		// 	$("#contents").find('input').click(function(){
		// 		// 		$('.inp-box.active').removeClass('active');
		// 		// 		popupClose($('.ui-popup.active'), targetEL);
		// 		// 		// $(this).addClass('active')
		// 		// 		console.log('닫기22222')
		// 		// 	})
		// 		// }
		// 		// console.log('닫기111')
		// 		if($(popID).is(".action.type02.active")){
		// 			var Ph = $(popID).find('.ui-popup-group').innerHeight();
		// 			$(".ui-contents").addClass("pop-active").css({'padding-bottom':Ph})

		// 			// 스크롤 이동
		// 			var offset = $(event.target).offset();
		// 			var Inp_height = $(event.target).height()
		// 			var window_height = $(window).height()
		// 			$("html,body").animate({scrollTop:offset.top - window_height/2.5 + Inp_height/1.3},200)

		// 			// console.log(offset.top)
		// 			// console.log(Inp_height)
		// 			// console.log(window_height)
		// 			// console.log(Inp_offset)

		// 			// var tab_Left_Offset = tabLi.children().offset().left //활성화된 탭 왼쪽 위치값
		// 			// var tab_Right_Offset = tabLi.children().offset().left + tabLi.children().outerWidth(); //활성화된 탭 오른쪽 위치값
		// 			// var tab_Head_Width = tabH.width(); //탭해더 넓이
		// 			// var tabRight = tab.outerWidth(); //탭해더 오른쪽 위치값
		// 			// var tabLeft = tab.offset().left; //탭해더 왼쪽 위치값
		// 			// var tabScroll = tabH.scrollLeft(); //탭 스크롤 위치값

		// 			// if(tabLeft > tab_Left_Offset){
		// 			// 	tabH.animate({scrollLeft:tabScroll + tab_Left_Offset - 4},300)
		// 			// }else if(tabRight < tab_Right_Offset){
		// 			// 	tabH.animate({scrollLeft:tabScroll + tab_Right_Offset - tab_Head_Width - 4},300)
		// 			// }
		// 		}
		// 		bottomScroll(); // 바텀시트 스크롤 이벤트
		// 		bottomHandlerBar(); // 바텀시트 핸들바
		// 	}
		// }

		// 인풋 클릭시 히든
		if ($('.ui-popup.action.active').length > 0)  {
			if(!$(event.target).is(".action.active")){
				popupClose($('.ui-popup.action'), targetEL);
				$('html, body').css('overflow','hidden');
			}
		}
		$(popID).addClass('active');
		$(popID).find('> div').focus();0
		$(popID).find('.ui-popup-group').removeAttr('tabindex');
		
		if($(popID).hasClass("action")){
			if(!$(event.target).is(".action.active")){
				$(popID).find('.ui-popup-group').css("bottom","-100vh").stop().animate({'bottom':0},150);
			}
			// if($(popID).hasClass("action type02")){
			// 	$("#contents").find('input').click(function(){
			// 		$('.inp-box.active').removeClass('active');
			// 		popupClose($('.ui-popup.active'), targetEL);
			// 		// $(this).addClass('active')
			// 		console.log('닫기22222')
			// 	})
			// }
			// console.log('닫기111')
			if($(popID).is(".action.type02.active")){
				var popHeight = $(popID).find('.ui-popup-group').innerHeight();
				$(".ui-contents").addClass("pop-active").css({'padding-bottom':popHeight})

				// 스크롤 이동
				var offset = $(event.target).offset();
				var Inp_height = $(event.target).height()
				var window_height = $(window).height()
				$("html,body").animate({scrollTop:offset.top - window_height/2.5 + Inp_height/1.3},200)

				// console.log(offset.top)
				// console.log(Inp_height)
				// console.log(window_height)
				// console.log(Inp_offset)

				// var tab_Left_Offset = tabLi.children().offset().left //활성화된 탭 왼쪽 위치값
				// var tab_Right_Offset = tabLi.children().offset().left + tabLi.children().outerWidth(); //활성화된 탭 오른쪽 위치값
				// var tab_Head_Width = tabH.width(); //탭해더 넓이
				// var tabRight = tab.outerWidth(); //탭해더 오른쪽 위치값
				// var tabLeft = tab.offset().left; //탭해더 왼쪽 위치값
				// var tabScroll = tabH.scrollLeft(); //탭 스크롤 위치값

				// if(tabLeft > tab_Left_Offset){
				// 	tabH.animate({scrollLeft:tabScroll + tab_Left_Offset - 4},300)
				// }else if(tabRight < tab_Right_Offset){
				// 	tabH.animate({scrollLeft:tabScroll + tab_Right_Offset - tab_Head_Width - 4},300)
				// }
			}
			bottomScroll(); // 바텀시트 스크롤 이벤트
			bottomHandlerBar(); // 바텀시트 핸들바
		}

		// 인풋 박스 active
		if($(event.target).closest('.inp-wrap').length > 0){
			$('.inp-wrap.active').removeClass('active');
			$(event.target).closest('.inp-wrap').addClass('active');
		}else{
			$('.inp-box.active').removeClass('active');
			$(event.target).closest('.inp-box').addClass('active');
		}

		// if($(event.target).closest('.inp-wrap').length > 0){
		// 	if($(event.target).closest('.inp-wrap').hasClass('active')){
		// 		$(event.target).closest('.inp-wrap').removeClass('active');
		// 	}else{
		// 		$('.inp-wrap.active').removeClass('active');
		// 		$(event.target).closest('.inp-wrap').addClass('active');
		// 	}
		// }else{
		// 	if($(event.target).closest('.inp-box').hasClass('active')){
		// 		$(event.target).closest('.inp-box').removeClass('active');
		// 	}else{
		// 		$('.inp-box.active').removeClass('active');
		// 		$(event.target).closest('.inp-box').addClass('active');
		// 	}
		// }
		
		// if(event && $(event.target).closest('.inp-box').length > 0){
		// 	if($(event.target).closest('.inp-wrap').length > 0){
		// 		if($(event.target).closest('.inp-wrap').hasClass('active')){
		// 			$(event.target).closest('.inp-wrap').removeClass('active');
		// 		}else{
		// 			$('.inp-wrap.active').removeClass('active');
		// 			$(event.target).closest('.inp-wrap').addClass('active');
		// 		}
		// 	}else{
		// 		if($(event.target).closest('.inp-box').hasClass('active')){
		// 			$(event.target).closest('.inp-box').removeClass('active');
		// 		}else{
		// 			$('.inp-box.active').removeClass('active');
		// 			$(event.target).closest('.inp-box').addClass('active');
		// 		}
		// 	}
		// }  


		// 주기선택
		if($(popID).hasClass("pop-cycle-select")){
			var now = new Date()
			var year = now.getFullYear();
			var selectList = $(".select-list.year").find(".list-item")
			selectList.each(function(index, item){
				$(item).children(".item").text(year - index + "년")
			});
			selectList.find(".item").click(function(e){
				e.preventDefault();
			});
			// $(".pop-cycle-select").find(selectList).children(".item")

		}


		popupCloseHandler(targetEL, callback);
		accordionHandler();
		bottomData(); // 임시 테스트 함수 삭제예정
		// console.log("uiPopup-Open")
		
	}
};

var popupCloseHandler = function(targetEL, callback){
	// $(document).off('click', '.ui-popup .ui-pop-close, .ui-popup .btn.cancel, .ui-popup .btn.close').on('click', '.ui-popup .ui-pop-close, .ui-popup .btn.cancel, .ui-popup .btn.close', function (e) {
	$(popID).find('.ui-pop-close, .calendar-zone .day-txt').on('click', function (e) {
		var popBtnCloseThis = $(this);
		var popup = popBtnCloseThis.closest('.ui-popup');
		
		// select-day 
		// console.log(popup)
		// console.log(targetEL)
		// if ($(targetEL).closest('.inp-item').find('input')) {
		// 	$(targetEL).closest('.inp-item').find('input').val('aaaaaaaaaaaaaa')
		// }

		if(typeof callback === 'function') {
			callback(popBtnCloseThis);
		}
		popupClose(popup, targetEL);
		

		// if(typeof callback === 'function') {
		// 	callback(popBtnCloseThis);
		// }
		// if($(popID).hasClass("ui-popup action")){
		// 	$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},200, function() {
		// 		popupClose(popup, targetEL);
		// 	});
		// }else{
		// 	popupClose(popup, targetEL);
		// }

		// console.log("popup-Close")
	});
}
function popupClose(popup, targetEL){
	if($(popID).is(".ui-popup.action.active")){
		$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},200, function() {
			popup.removeClass('active');
			popup.find('.ui-popup-body').removeAttr('style');
			popup.find('.ui-popup-group').attr('tabindex','-1');
			if($('.ui-popup.active').length==0){
				$('html, body').removeAttr('style'); // 스크롤 가능
				$('#container').attr('aria-hidden','false'); // 컨텐츠 영역 읽힘
				$('.ui-header').removeAttr('style');
				$('.ui-scroll-top').removeAttr('style');
				$('.ui-footer').removeAttr('style');
			}
		});
		// 바텀 시트 하단 패딩
		if($(popID).is(".ui-popup.action.type02.active")){
			$(".ui-contents").removeClass("pop-active").removeAttr("style")
		}
	}else{
		// $(this).closest('.ui-popup').remove();
		popup.removeClass('active');
		popup.find('.ui-popup-body').removeAttr('style');
		popup.find('.ui-popup-group').attr('tabindex','-1');
		if($('.ui-popup.active').length==0){
			$('html, body').removeAttr('style'); // 스크롤 가능
			$('#container').attr('aria-hidden','false'); // 컨텐츠 영역 읽힘
			$('.ui-header').removeAttr('style');
			$('.ui-scroll-top').removeAttr('style');
			$('.ui-footer').removeAttr('style');
		}
	}

	// $(this).closest('.ui-popup').remove();
	// popup.removeClass('active');
	// popup.find('.ui-popup-body').removeAttr('style');
	// popup.find('.ui-popup-group').attr('tabindex','-1');
	// if($('.ui-popup.active').length==0){
	// 	$('html, body').removeAttr('style'); // 스크롤 가능
	// 	$('#container').attr('aria-hidden','false'); // 컨텐츠 영역 읽힘
	// 	$('.ui-header').removeAttr('style');
	// 	$('.ui-scroll-top').removeAttr('style');
	// 	$('.ui-footer').removeAttr('style');
	// }
	
	/*if(targetEL == '') {
		$('body').focus();
	} else {
		$(targetEL).focus();
	}*/
}


// 임시 바텀 테스트 데이터
var bottomData = function(){
	$(document).on("click","[data-info]",function(){
		var target = $(this);
		var dataItem = target.data('info');
		var dataBtn = $(".btn").data('btn');
		var targetClone = target.children().clone();
		// if(dataBtn == dataItem){
		// 	$("[data-btn]").filter("[data-btn="+ dataItem +"]").parent().siblings(".select-info").addClass("active").empty().append(targetClone);
		// 	$("[data-btn]").filter("[data-btn="+ dataItem +"]").closest(".inp-box.active").removeClass("active")
		// }
		
		if(dataBtn == dataItem){
			$("[data-btn]").filter("[data-btn=step01]").parent().siblings(".select-info").addClass("active").empty().append(targetClone);
			$("[data-btn]").closest(".inp-box.active").removeClass("active");
			// if($(popID).hasClass("action")){
			// 	$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},300, function() {
			// 		popupClose($(popID), '');
			// 	})
			// }else{
			// 	popupClose($(popID), '');
			// }
			// uiPopup.open('','#trns-pop-06');
			$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},300, function() {
				popupClose($(popID), '');
				setTimeout(function(){uiPopup.open('','#trns-pop-06');},300)
			})
			// $("[data-btn]").each(function(index,e){
			// 	var item = $(e)
			// 	// if(item.date() == "step02"){
					

			// 	// }
			// })
		}
		// if(){

		// }

		// if($(popID).hasClass("action")){
		// 	$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},300, function() {
		// 		popupClose($(popID), '');
		// 	})
		// }else{
		// 	popupClose($(popID), '');
		// }
	})
}



// 바텀시트 스크롤시 바텀시트 Full
var bottomScroll = function(){
	var timer;

	$(popID).find(".popup-content").on('scroll',function(){
		
		var thisScrollTop = $(this).scrollTop();
		var thisHeight = $(".ui-popup.action.active").find(".popup-content").innerHeight();
		var heightVh = window.innerHeight - 80
		var bottomAction = true;
			
		// 일정시간 지나면 실행
		// if(!timer){
		// 	timer = setTimeout(function(){
		// 			timer = null;
		// 			const scrollValue = thisScrollTop
		// 			console.log(scrollValue);
		// 	},300);
		// }
		
		// 한번만 실행
		if(timer){
			clearTimeout(timer);
		}
		timer = setTimeout(function(){
			const scrollValue = thisScrollTop
			console.log(scrollValue);
			if(!$(this).parents(".ui-popup.action").hasClass("none-handle")){
				if(0 < thisScrollTop){
					$(popID).find('.ui-popup-group').stop().animate({'height':heightVh,'maxHeight':'100vh'},150);
					$(popID).addClass('expand');
				}
			}
		},100);

		// if(!$(this).parents(".ui-popup.action").hasClass("none-handle")){
		// 	if(0 < thisScrollTop){
		// 		$(popID).find('.ui-popup-group').stop().animate({'height':heightVh,'maxHeight':'100vh'},150);
		// 		$(popID).addClass('expand');
				
		// 	}else if(thisScrollTop == 0){
		// 		$(popID).find('.ui-popup-group').stop().animate({'maxHeight':'60vh'},150,function(){
		// 			$(this).css({'height':'auto'});
		// 		});
		// 		$(popID).removeClass('expand');
		// 		console.log(444)
		// 	}
		// }
			
		// console.log(thisHeight)
		// console.log(thisScrollTop)
		// console.log(bottomAction)


		// if(!$(this).parents(".ui-popup.action").hasClass("none-handle")){
		// 	if(0 < thisScrollTop){
		// 		if(bottomAction == true){
		// 			$(popID).find('.ui-popup-group').stop().animate({'height':heightVh,'maxHeight':'100vh'},150);
		// 			$(popID).addClass('expand');
		// 			bottomAction = false;
		// 		}
				
		// 	}else if(thisScrollTop == 0){
		// 		$(popID).find('.ui-popup-group').stop().animate({'maxHeight':'60vh'},150,function(){
		// 			$(this).css({'height':'auto'});
		// 		});
		// 		$(popID).removeClass('expand');
		// 		console.log(444)
		// 	}
		// }
	})
}


// 바텀시트 핸들바
var bottomHandlerBar = function(){
	var startY, endY;
	var heightVh = window.innerHeight - 80

	$(".popup-handle-wrap .handle-bar").on("touchstart",function(e){
		startY = e.originalEvent.changedTouches[0].screenY;
	});
	$(".popup-handle-wrap .handle-bar").on("touchend",function(e){
		endY = e.originalEvent.changedTouches[0].screenY;
	});


	$(".ui-popup.action").not(".none-handle").find(".popup-handle-wrap .handle-bar").on({
		click:function (){
			if($(popID).hasClass('expand')){
				$(popID).find('.ui-popup-group').stop().animate({'maxHeight':'60vh'},150,function(){
					$(this).css({'height':'auto'});
				});
				$(popID).removeClass('expand');
				$(this).children('span').text($(this).text().replace('축소하기','확장하기'))
			}else{
				$(popID).find('.ui-popup-group').stop().animate({'height':heightVh,'maxHeight':heightVh},150);
				$(popID).addClass('expand');
				$(this).children('span').text($(this).text().replace('확장하기','축소하기'))
			}
		},
		touchend:function(){
			if(startY + 50 < endY && $(popID).hasClass('expand')){
				$(popID).find('.ui-popup-group').stop().animate({'maxHeight':'60vh'},150,function(){
					$(this).css({'height':'auto'});
				});
				$(popID).removeClass('expand');
				$(this).children('span').text($(this).text().replace('확장하기','축소하기'))
			}else if(startY > endY + 50 && !$(popID).hasClass('expand')){
				$(popID).find('.ui-popup-group').stop().animate({'height':heightVh,'maxHeight':heightVh},150);
				$(popID).addClass('expand');
				$(this).children('span').text($(this).text().replace('축소하기','확장하기'))
			}
			// 닫기
			// else if(startY + 50 < endY && !$(popID).hasClass('expand')){
			// 	$(popID).find('.ui-popup-group').stop().animate({'bottom':'-100vh'},300, function() {
			// 		popupClose($(popID),'');
			// 		$(popID).removeClass('expand');
			// 	})
			// 	console.log('44444')
			// }
			
		}
	});		

		// $(".popup-handle-wrap .handle-bar").on("click touchend",function(){
	// 	console.log(startY + 'start')
	// 	console.log(endY + 'end')
	// 	var hVh = window.innerHeight - 80
	// 	if(startY + 50 < endY && $(popID).hasClass('full')){
	// 		$(popID).find('.ui-popup-group').stop().animate({'maxHeight':'60vh'},150,function(){
	// 			$(this).css({'height':'auto'});
	// 		});
	// 		$(popID).removeClass('full');
	// 	}else if(startY > endY + 50 && !$(popID).hasClass('full')){
	// 		$(popID).find('.ui-popup-group').stop().animate({'height':hVh,'maxHeight':hVh},150);
	// 		$(popID).addClass('full');
	// 	}
	// });
}


// 리프래시 버튼
function refreshBtn(target,findStr ,isBool) {
	if($(target).find(findStr).length){
		if(isBool){
			$(target).addClass('active');
			TweenMax.killTweensOf($(target).find(findStr),{rotation:'0'});
			loop();
		}else{
			$(target).removeClass('active');
			TweenMax.killTweensOf($(target).find(findStr),{rotation:'0'});
			$(target).find(findStr).removeAttr('style');
		}

		function loop(){
			TweenMax.set($(target).find(findStr),{rotation:'0'});
			TweenMax.to($(target).find(findStr), 1, {rotation:'360deg', ease:Power0.easeNone, onComplete:function(){
				loop();
			}});
		}
	}
};

// 새로고침 rotation
function rotateBtn(target, findStr ,isBool) {
	if($(target).find(findStr).length){
		if(isBool){
			TweenMax.to($(target).find(findStr), 1, {rotation:'360deg', repeat:-1, ease:Power0.easeNone});
		}else{
			TweenMax.killTweensOf($(target).find(findStr),{rotation:'0', repeat:0, ease:Power0.easeNone});
			$(target).find(findStr).removeAttr('style');
		}
	}
}

// 파이차트
var PieChartFnc = {
	DEFAULTS: {
		strokeWidth:28, // 그래프 두깨
		slice: [
			{text:'예금', percent:10, color:'red'},
			{text:'적금', percent:40, color:'blue'}
		],
		gapTime : 0.7
	},
	init: function(target, option) {
		this.container = target;
		this.targetID = this.container.attr('id');
		this.opt = $.extend({},PieChartFnc.DEFAULTS, option);
		this.svg = this.container.find('svg');
		this.arcW = this.svg.outerWidth();
		this.pieChartAdd();
		this.labelHandler();
		this.initHandler();
	}
};

PieChartFnc.init.prototype.pieChartAdd = function(){
	var _this=this;
	for(var a=0; a<_this.opt.slice.length; a++){
		_this.container.find('#'+_this.targetID+'_path'+a).attr('fill', _this.opt.slice[a].color);
	}
};

PieChartFnc.init.prototype.initHandler = function(){
	var _this = this;
	var count=0;
	var game = {score:0};
	var total = _this.opt.slice.length;
	creatChartInit();
	function creatChartInit(){
		var chkRotateNum = (count>0)?totalNum()-0.06:0;
		var scoreNum = chkNum(_this.opt.slice[count].percent)/100*359.999999;
		TweenMax.set($('#'+_this.targetID+'_path'+count).parent().parent(),{transform:'rotate('+chkRotateNum+'deg)'});
		TweenMax.to(game, _this.opt.gapTime, {score:scoreNum, ease:Power2.easeOut, onUpdate:function(){
			var path=_this.describeArc(_this.arcW/2, _this.arcW/2, _this.arcW/2-_this.opt.strokeWidth,_this.opt.strokeWidth, 0, game.score);
			TweenMax.set($('#'+_this.targetID+'_path'+count), {attr:{d:path}});
		},onComplete:function(){
			count++;
			game = {score:0};
			if(count<total){
				creatChartInit();
			}
		}});
	}

	function totalNum(){
		var num = 0;
		for(var a=0; a<count; a++){
			num += Number(_this.opt.slice[a].percent);
		}
		return (num/100)*359.999999;
	}

	function chkNum(num){
		if(num>=100){
			num=99.999;
		}
		if(num<=0){
			num=0.001;
		}
		return num;
	}
};

PieChartFnc.init.prototype.labelHandler = function(){
	var _this = this, arrOfLabel=[];
	for(var a=0; a<_this.opt.slice.length; a++){
		arrOfLabel.push(String(_this.opt.slice[a].text)+' '+String(_this.opt.slice[a].percent)+'%');
	}
	_this.container.attr('aria-label', '보유비중 ' + arrOfLabel.join(', '));
};

PieChartFnc.init.prototype.describeArc = function(x, y, radius, spread, startAngle, endAngle) {
	var _this=this;
	var innerStart = _this.polarToCartesian(x, y, radius, endAngle);
	var innerEnd = _this.polarToCartesian(x, y, radius, startAngle);
	var outerStart = _this.polarToCartesian(x, y, radius+spread, endAngle);
	var outerEnd = _this.polarToCartesian(x, y, radius+spread, startAngle);
	var largeArcFlag = endAngle - startAngle <=180?"0":"1";

	var d =[
		"M",outerStart.x, outerStart.y,
		"A",radius+spread, radius + spread, 0, largeArcFlag, 0, outerEnd.x, outerEnd.y,
		"L",innerEnd.x, innerEnd.y,
		"A",radius,radius,0,largeArcFlag, 1, innerStart.x, innerStart.y,
		"L",outerStart.x, outerStart.y,"Z"
	].join(' ');
	return d;
}

PieChartFnc.init.prototype.polarToCartesian = function(centerX, centerY, radius, angleInDegrees) {
	var angleInRadius = (angleInDegrees-90)*Math.PI/180.0;
	return {
		x:centerX + (radius * Math.cos(angleInRadius)),
		y:centerY + (radius * Math.sin(angleInRadius))
	};
}

$.fn.PieChart = function(options) {
	var opt = $.extend({}, PieChartFnc.DEFAULTS, options);
	return new PieChartFnc.init($(this), opt);
}

// 출금계좌 스크롤 시 출금가능 금액 로드
var withrawScrollHandler = function(id){
	setTimeout(function(){
		if($(id).find('.tab-con-inner').length){
			$(id).find('.tab-con-inner').scrollTop(0);
			// li가 10개 이상일 경우
			if($(id).find('.tab-con-inner .search-result-group li').length>=10){
				var gap = $(id).find('.tab-con-inner .search-result-group > li').outerHeight();
				var totalLen = $(id).find('.tab-con-inner .search-result-group > li').length;
				$(id).find('.tab-con-inner').off('scroll').on('scroll', function(e){
					var scrollNum = $(this).scrollTop();
					if(scrollNum>0){
						var resultNum = parseInt(scrollNum/gap)+8;
						if(resultNum>0){
							var ele = $(id).find('.tab-con-inner .search-result-group > li').eq(resultNum);
							if(totalLen>resultNum){
								if(ele.find('.btn-account').attr('data-loaded')=='false'){
									var code = ele.find('.btn-account').attr('data-code');
									dataLoad(ele.find('.btn-account'), code);
								}
							}
						}
					}
				});
			}
		}
	},10);
};



// 셀렉트 박스
var CustomSelectBoxInit = function(){
	
	$('.ui-select-group').each(function(index,item){
		$(item).addClass('num0'+index);
		
	});
	var select00 = new CustomSelectBox('.ui-select-group.num00');
	var select01 = new CustomSelectBox('.ui-select-group.num01');
	var select02 = new CustomSelectBox('.ui-select-group.num02');
	var select03 = new CustomSelectBox('.ui-select-group.num03');
	var select04 = new CustomSelectBox('.ui-select-group.num04');
	var select05 = new CustomSelectBox('.ui-select-group.num05');
	var select06 = new CustomSelectBox('.ui-select-group.num06');
	var select07 = new CustomSelectBox('.ui-select-group.num07');
	var select08 = new CustomSelectBox('.ui-select-group.num08');
	var select09 = new CustomSelectBox('.ui-select-group.num09');
	var select10 = new CustomSelectBox('.ui-select-group.num10');
	var select09 = new CustomSelectBox('.ui-select-group.num11');
	var select10 = new CustomSelectBox('.ui-select-group.num12');
};

function CustomSelectBox(selector){
	this.$selectBox = null,
	this.$select = null,
	this.$list = null,
	this.$listLi = null;

	CustomSelectBox.prototype.init = function(selector){
		this.$selectBox = $(selector);
		this.$select = this.$selectBox.children('.select');  //  view버튼
		this.$list = this.$selectBox.children('.select-list');  // 리스트박스
		this.$listLi = this.$list.children('li');           // 리스트들
		
	},

	CustomSelectBox.prototype.initEvent = function(e){
		var that = this;
		this.$select.on('click',function(e){
			that.listOn();
			
	
		});
		this.$listLi.on('click',function(e){
			that.listSelect($(this));
			
		});
		$(document).on('click',function(e){
			that.listOff($(e.target));

		});
	},

	CustomSelectBox.prototype.listOn = function(){
		this.$selectBox.toggleClass('on');
		if(this.$selectBox.hasClass('on')){
			$('.select').attr('aria-expanded','false'); // 추가
		    $('.select-list').css('display', 'none');   // 추가
			this.$list.css('display', 'block');
			this.$select.attr('aria-expanded','true');
		} else {
			this.$list.css('display', 'none');
			this.$select.attr('aria-expanded','false');
		};
	},

	CustomSelectBox.prototype.listSelect = function($target){
		// $target  선택한 li
		$target.addClass('selected').siblings('li').removeClass('selected');
		$target.attr('aria-selected','true').siblings('li').attr('aria-selected','false');
		$target.parent().next("input[type='text']").val($target.find('span').attr('data-value'));  //2차 - 추가개발대응  
		this.$selectBox.removeClass('on');
		this.$select.text($target.children().text());
		$('.select').attr('aria-expanded','false'); // 추가
		$('.select-list').css('display', 'none');   // 추가
		console.log($target);
	},

	CustomSelectBox.prototype.listOff = function($target){
		if(!$target.is(this.$select) && this.$selectBox.hasClass('on')){
			this.$selectBox.removeClass('on');
		    this.$target.attr('aria-selected','false');
		    this.$list.css('display', 'none');

		};
	},

	this.init(selector);
	this.initEvent();
	
};

// 프린트
function pagePrint() {
	print();
}	


// 로딩바
/*
 * mask Screen 초기화
 */
$(document).ready(function() {
	//화면로딩바 초기화
	//drawLoadingBar();
});

$(document).ready(function() {
	$(".select-jq").selectmenu();
});

function drawLoadingBar(){
	var loadingBar = document.getElementById( "LOADING_BAR" );
	//화면에 loading_bar div 가 없을경우만 그림.
	if( loadingBar == undefined ){
		var $loading = $("<div id=\"LOADING_BAR\" class=\"loadingbar\">"
				+ "<img id=\"loading_img\" src=\"/img/pb/common/img/loading.gif\" alt=\"처리중입니다\"/>"
				+ "<p><img src=\"/img/pb/common/img/process.gif\" alt=\"처리중입니다\" /></p>"
				+ "</div>");
		var $mask = $("<div id='mask'></div>");
		
		$(document.body).append($loading);
		$(document.body).append($mask);
		
		var loadingHeight = 166;
		var loadingWidth  = 326;
		$loading.dialog({
			width		: loadingWidth, 
			height		: loadingHeight,
			modal		: true, 
			zIndex		: 10000,
			resizable	: false,
			closeOnEscape:false,
			bgiframe	: true,
			autoOpen	: false,
			create: function(event, ui) {
				var imgTop  = $(window).scrollTop() + (($(window).height() - loadingHeight) / 2);
				var imgLeft = $(window).scrollLeft() + (($(window).width() - loadingWidth) / 2);
				
				$(".ui-dialog-titlebar").hide();
				$(this).parent().css({"top":imgTop,"left":imgLeft,"overflow":"hidden","padding":"0px","border":"0px","background":"transparent"});
				$(this).css({"overflow":"hidden","padding":"0px","border":"0px","width":"100%","height":"100%"}); 
			}
		});
		
		$('#mask').css({
			'width' : '100%',
			'height' : $(document.body).height(),
			'filter' : 'alpha(opacity=75)'
		});
	}
}

function loading(flag) {
	if (flag != undefined) {
		submitFlag = flag;
		if (flag) {
			$("#LOADING_BAR").dialog("open");
		} else {
			$("#LOADING_BAR").dialog("close");
		}
	}
	return submitFlag;
}

// 스와이퍼 모음
var SwiperModule = function(){

	$(document).ready(function(){

		var TabSwiper01 = new Swiper("[data-tab-slide='tab-slide01'] > .swiper-container.tab-body",{
			slidesPerview:1,
			spaceBetween: 0,
			centeredSlides:true,
			// loop:true,
			observer:true,
			observeParents:true,
			autoHeight:true,
			// freemode:true,
			// navigation: {
			// 	nextEl:'.swiper-button-next',
			// 	prevEl:'.swiper-button-prev'
			// },
			// pagination:{
			// 	el:".swiper-pagination",
			// 	clickable:true,
			// 	renderBullet:function(index, className){
			// 		return '<button type="button" class="'+ className +'" title="'+(index+1)+'번째 슬라이드로 이동"></button>'
			// 	}
			// }
			on:{
				slideChange:function(){
					var tabSlider = $("[data-tab-slide='tab-slide01'] > .tab-heading-wrap > .tab-heading");
					var tabList = tabSlider.find("[role='tab']");
					var slidelist = $("[data-tab-slide='tab-slide01'] > .swiper-container > .swiper-wrapper").children(".swiper-slide.tab-con");

					tabList.parent().removeClass("on").eq(this.activeIndex).addClass("on")
					tabList.attr('aria-selected','false').eq(this.activeIndex).attr('aria-selected','true');
					slidelist.attr("aria-hidden","true").eq(this.activeIndex).attr("aria-hidden","false");
					// $(".swiper-slide.tab-con").attr("aria-hidden","true");
					// $(".swiper-slide-active.tab-con").attr("aria-hidden","false");
					
					if($("[data-tab-slide='tab-slide01'] > .tab-heading-wrap.scroll-x").length){
						var tab = $("[data-tab-slide='tab-slide01']");
						var tabH = tab.find(".tab-heading-wrap.scroll-x .tab-heading")
						var tabLi = tab.find(".tab-heading-wrap.scroll-x .tab-heading > li.on")
						var tab_Left_Offset = tabLi.children().offset().left //활성화된 탭 왼쪽 위치값
						var tab_Right_Offset = tabLi.children().offset().left + tabLi.children().outerWidth(); //활성화된 탭 오른쪽 위치값
						var tab_Head_Width = tabH.width(); //탭해더 넓이
						var tabRight = tab.outerWidth(); //탭해더 오른쪽 위치값
						var tabLeft = tab.offset().left; //탭해더 왼쪽 위치값
						var tabScroll = tabH.scrollLeft(); //탭 스크롤 위치값

						if(tabLeft > tab_Left_Offset){
							tabH.animate({scrollLeft:tabScroll + tab_Left_Offset - 4},300)
						}else if(tabRight < tab_Right_Offset){
							tabH.animate({scrollLeft:tabScroll + tab_Right_Offset - tab_Head_Width - 4},300)
						}
					}
				},
				init:function(){
					var noti = $("[data-tab-slide='tab-slide01']").find(".swiper-notification");
					if(noti.length >= 1){
						$("[data-tab-slide='tab-slide01']").find(".swiper-notification").remove();
					}
				}
			}
		});
		$(document).on('click', "[data-tab-slide='tab-slide01'] > .tab-heading-wrap li", function(){
			var con = $(this).parents('.tab-heading-wrap').next('.tab-body');
			if(con.length){
				con.find('.tab-con').css('display','');
				if(con.find('.swiper-slide.tab-con').length){
					var Index = $(this).index()
					TabSwiper01.slideTo(Index);
					// $(".swiper-slide.tab-con").attr("aria-hidden","true");
					// $(".swiper-slide-active.tab-con").attr("aria-hidden","false");
				}
			}
		});

		// 주기선택 스와이퍼
		var popupCycleSelect = new Swiper('.cycle-select-list .select-list',{
			slidesPerview:'auto',
			// freeMode:true,
			spaceBetween: 0,
			direction:'vertical',
			// centeredSlides:true,
			slideToClickedSlide:true,
			observer:true,
			observeParents:true,
			autoHeight:true,
			// loop:true,
			// loopAdditionalSildes:1,
			// initialSlide:2
		});

		// var popupSwiper = new Swiper('.popup-container',{
		// 	slidesPerview: 1,
		// 	speed: 10,
		// 	touchRatio: 0,
		// 	observer:true,
		// 	observeParents:true,
		// 	navigation: {
		// 		nextEl:'.swiper-button-next',
		// 		prevEl:'.swiper-button-prev'
		// 	},
		// });

		// var cardSwiper = new Swiper('.card-slide-area',{
		// 	slidePerviews: 1,
		// 	speed: 10,
		// 	touchRatio: 0,
		// 	observer:true,
		// 	observeParents:true,
		// 	navigation: {
		// 		nextEl:'.swiper-button-next',
		// 		prevEl:'.swiper-button-prev'
		// 	},
		// });

		var cardSwiper = new Swiper('.cardswiper',{
			slidePerviews: 1,
			speed: 500,
			pagination: {
				el: '.pagination-area',
				type : 'fraction',
			},
			navigation: {
				nextEl:'.swiper-button-next',
				prevEl:'.swiper-button-prev'
			},
		});


	})
}


// 예약이체 체크
var reservationHandler = function() {
	if($('.reserv-group').length){
		$('.reserv-group .reserv-rdo-group label').on('click', function(){
			var txt = $(this).find('.inp-txt').text()
			if(txt=='즉시이체'){
				moveScrollHandler();
				$('.reserv-group .reserv-item').addClass('none');
				$(window).trigger('resize');
			}else if(txt=='예약이체'){
				moveScrollHandler();
				$('.reserv-group .reserv-item').removeClass('none');
				$(window).trigger('resize');

			}
		});
	}
};

// 이체 > 입금계좌 선택시 스크롤 이동
var moveScrollHandler = function(){
	if($('.header-group').hasClass('to-scroll')){
		var $this = $('.header-group.to-scroll');
		$this.siblings('.ui-table-group').addClass('click-scroll');
		var offSetTop = $('.header-group.to-scroll').offset().top;
		$(document).off('click', '.click-scroll .search-result-group li > .bank-list').on('click','.click-scroll .search-result-group li > .bank-list', function(){
			if(!$('.table.default.small.text-top').length){
				$('html, body').animate({scrollTop:offSetTop - 60},300);
			}
		})
	}
};


// 캘린더
var calendarAllGroupHandler = function(){
	$(document).on('click', '.ui-popup .fromto-btn, .fromtoall-btn', function(){
		var str = null;
	var $calGroup = $(this).closest('[data-group="calendar"]'); /* 20220620 추가 */

		if($(this).hasClass('fromtoall-btn'))		str="all"
		else if($(this).hasClass('fromto-btn'))		str=''
		var value = dateValue($(this).find('.ui-text').text(), str);
		if($(this).hasClass('fromtoall-btn')) {
			$calGroup.find('.calendar-select-all-group .fromto-all').val(value.join(' ~ ')); /* 20220620 수정 */
		}
		$('.fromtoall-btn').removeClass('active');
		$('.ui-popup .fromto-btn').removeClass('active');

		var clickVal = $(this).attr('data-val');

    var $calFromInput = $calGroup.find('input.from-day'); /* 20220620 추가 */
    var $calToInput   = $calGroup.find('input.to-day'); /* 20220620 추가 */

		/* 20220620 수정 */
		if($calFromInput.length){
			$calFromInput.val(value[0]).attr({'data-fromdate': value[0], 'data-todate': value[1], 'data-date': value[0]});
			$calFromInput.trigger('change');
		}
		if($($calToInput).length){
			$($calToInput).val(value[1]).attr({'data-fromdate': value[0], 'data-todate': value[1], 'data-date': value[1]});
			$($calToInput).trigger('change');
		}
	});

	$(document).on('click', '.calendar-select-all-group .rdo-btn, .calendar-select-group .rdo-btn', function(){
		var str = null;
		if($(this).hasClass('ui-all'))			str="all"
		else if($(this).hasClass('ui-piece'))	str=''
		var value = dateValue($(this).find('+ .inp-txt').text(), str);
		if($(this).hasClass('ui-all')) {
			$('.calendar-select-all-group .fromto-all').val(value.join(' ~ '));
		}

		var total = $('.calendar-select-all-group .chk-btn-list').length;
		var clickVal = $(this).find('+ .inp-txt').text();
		for(var a=0; a<total; a++){
			if($('.calendar-select-all-group .chk-btn-list').eq(a).find('.rdo-btn + .inp-txt').text() == clickVal){
				$('.calendar-select-group .chk-btn-list').eq(a).find('.rdo-btn').prop('checked', true);
			}
			if($('.calendar-select-group .chk-btn-list').eq(a).find('.rdo-btn + .inp-txt').text() == clickVal){
				if($('.fromto-all').val().length){
					$('.calendar-select-all-group .chk-btn-list').eq(a).find('.rdo-btn').prop('checked', true);
				}
			}
		}
		
		if($('input.from-day').length){
			$('input.from-day').val(value[0]).attr({'data-fromdate': value[0], 'data-todate': value[1], 'data-date': value[0]});
			$('input.from-day').trigger('change');
		}
		if($('input.to-day').length){
			$('input.to-day').val(value[1]).attr({'data-fromdate': value[0], 'data-todate': value[1], 'data-date': value[1]});
			$('input.to-day').trigger('change');
		}
	});
};

var dateValue = function(val, type) {
	var date = new Date(),
		curYear = date.getFullYear(),
		curMonth = date.getMonth()+1,
		curDay = date.getDate(),
		fromDate = '',
		toDate = '',
		calcDate = null,
		calcDayNum = 0,
		calcMonthNum = 0,
		calcYearNum = 0;

	if(val=='오늘'){
		calcDayNum=0;
	} else if(val=='3일'){
		calcDayNum=-2;
	} else if(val=='1주일'){
		calcDayNum=-6;
	} else if(val=='1개월'){
		calcMonthNum=-1;
		calcDayNum=-1;
	} else if(val=='3개월'){
		calcMonthNum=-3;
		calcDayNum=-1;
	} else if(val=='6개월'){
		calcMonthNum=-6;
		calcDayNum=-1;
	} else if(val=='1년'){
		calcYearNum=-1;
		calcDayNum=-1;
	} else if(val=='2년'){
		calcYearNum=-2;
		calcDayNum=-1;
	}
	var toChkMonth = ((date.getMonth()+1)<10)?'0'+(date.getMonth()+1):(date.getMonth()+1),
		toChkDate = (date.getDate()<10)?'0'+date.getDate():date.getDate();
	calcDate = new Date(curYear+calcYearNum, curMonth+calcMonthNum, curDay+calcDayNum, 0, 0);
	var fromChkMonth = (calcDate.getMonth()<10)?'0'+(calcDate.getMonth()):calcDate.getMonth(),
		fromChkDate = (calcDate.getDate()<10)?'0'+calcDate.getDate():calcDate.getDate();
	fromDate = calcDate.getFullYear()+'.'+fromChkMonth+'.'+fromChkDate;
	toDate = curYear+'.'+toChkMonth+'.'+toChkDate;

	return [fromDate,toDate];
};

// // 테이블 외부 sorting 버튼
// var sortingBtnHandler = function() {
// 	$('.ui-sorting-group > .btn-sort').on('click', function(){
// 		if($(this).hasClass('on')) {
// 			$(this).siblings().removeClass('on');
// 			$(this).siblings().attr('title','정렬 안 함');
// 			$(this).siblings().attr('aria-label','정렬 안 함');
// 			$(this).removeClass('on');
// 			$(this).attr('title','오름차순 정렬');
// 			$(this).attr('aria-label','오름차순 정렬');

// 		} else {
// 			$(this).siblings().removeClass('on');
// 			$(this).siblings().attr('title','정렬 안 함');
// 			$(this).siblings().attr('aria-label','정렬 안 함');
// 			$(this).addClass('on');
// 			$(this).attr('title','내림차순 정렬');
// 			$(this).attr('aria-label','내림차순 정렬');
// 		}
// 	}
// )};
	
// // 테이블 내부 sorting 버튼
// var sortingBtnHandler2 = function() {
// 	$('.sorting th >.btn-sort').on('click', function(){
// 		if($(this).hasClass('on')) {
// 			$(this).parent().siblings().find('.btn-sort').removeClass('on');
// 			$(this).parent().siblings().find('.btn-sort').attr('title','정렬 안 함');
// 			$(this).parent().siblings().find('.btn-sort').attr('aria-label','정렬 안 함');
// 			$(this).removeClass('on');
// 			$(this).attr('title','오름차순 정렬');
// 			$(this).attr('aria-label','오름차순 정렬');

// 		} else {
// 			$(this).parent().siblings().find('.btn-sort').removeClass('on');
// 			$(this).parent().siblings().find('.btn-sort').attr('title','정렬 안 함');
// 			$(this).parent().siblings().find('.btn-sort').attr('aria-label','정렬 안 함');
// 			$(this).addClass('on');
// 			$(this).attr('title','내림차순 정렬');
// 			$(this).attr('aria-label','내림차순 정렬');
// 		}
// 	}
// )};


// 다중 버튼 (캘린더, 금액선택)
var multipleBtnHandler = function() {
	$('.btn-group .btn.multiple,.money-btn-group .btn').on('click', function(){
		if($(this).hasClass('on')) {
			$(this).siblings().removeClass('on');
		} else {
			$(this).addClass('on');
			$(this).siblings().removeClass('on');
		}
	}
)};

// 조회 인풋 활성화 버튼
var searchBtnHandler = function() {

	$('.text-group .btn.search').each(function(){
		
		$(this).on('click', function(){
			//$(this).parent('.text-group').addClass('on');
			//$(this).siblings('input').val('').focus();
			var searchThis = $(this);
			console.log('111');
			if(!$('.text-group').hasClass('on')) {
				$(this).parent('.text-group').addClass('on');
			} 
		});
	});
};

// 조회 설정
// var inqySsetupBox = function() {	
// 	$('.inqy-setup-box .btn-box').find('.btn-inqy').on('click', function(){
// 		$(this).siblings('.btn-inqy').removeClass('active').next('.info-txt').hide();
// 		$(this).addClass('active').next('.info-txt').show();
// 	});

// };

// 카드형/리스트형 버튼
// var viewtypeBtnHandler = function() {	
// 	$('.btn-group .viewtype-btn').on('click', function(){
// 		if($(this).hasClass('active')) {
// 			$(this).siblings().removeClass('active');
// 		} else {
// 			$(this).siblings().removeClass('active');
// 			$(this).addClass('active');
// 		}
// 	}
// )};

// var viewtypeHandler = function() {	
// 	if($('.btn-group .viewtype-btn.card').hasClass('active')){
// 		$(this).parent().addClass('card');
// 	} else {
// 		$(this).parent().removeClass('card');
// 	}
// };


//  trigger-con 테이블 공통+title
var triggerTableHandler = function(){
	
	$(document).on('click', '.trigger-con tr', function(){
		if(true)
		{
			$(this).find('.btn-trigger').get(0).click();	 // trigger
		}
 	});
	$(document).on('click', '.trigger-con button', function(e){
		e.preventDefault();	
		e.stopPropagation();
 	});	
	 $(document).on('click', '.trigger-con a.btn-option', function(e){	
		e.stopPropagation();
 	});	
	 //$('.trigger-con tr td:nth-child(-n+4)')
	 // $('.trigger-con tr td').find('button')
	 // $('.trigger-con tr td').find('a').not('.btn-option')// id를 가진 a는 제외
	 // td안에 
	$('.trigger-con tr td').hover(function(){
		if(!$(this).find('a').hasClass('btn-option') && !$(this).parents().find('.trigger-con').hasClass('trns-three-form')){   // 없다
			$(this).attr('title','선택 하시면 거래내역을 확인 하실 수 있습니다.');
		}
	 },function(){
		return false;
	});
};


// 	$('input[numberOnly]').attr("oninput","this.value=this.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1');");
var numberOnlyHandler = function() {
	$('input[type=number]').on('keyup', function(){
		$(this).val($(this).val().replace(/[^0-9]/g,'').replace(/(\..*)\./g,'$1'));	
		// if(!(($(this).keyCode > 95 && $(this).keyCode < 106)
		// || ($(this).keyCode > 47 && $(this).keyCode < 58)
		// || $(this).keyCode == 8)){
		// 	return false;
		// }
	});
};


// 금액수정/수정취소 버튼
var editBtnHandler = function() {
	$('.combinate-group.modify .btn-edit').on('click', function(){
		if($(this).hasClass('btn-edit')) {
			$(this).removeClass('btn-edit').addClass('btn-txt').text('수정취소');
			$(this).siblings('.right').removeClass('on');
			$(this).siblings('.left').addClass('on');
		} else {
			$(this).removeClass('btn-txt').addClass('btn-edit').text('금액수정');
			$(this).siblings('.left').removeClass('on');
			$(this).siblings('.right').addClass('on');
		}
	}
)};

// 뱅크체크리스트 - 이체폼
var bankCheckList = function() {
	$('.bank-checklist-group input[type=checkbox]').on('click',function(){
		if($(this).is(':checked')){
			$(this).parents('.bank-checklist').addClass('on')
		}else{
			$(this).parents('.bank-checklist').removeClass('on')
		}
	})

};

// 파일등록 - 버튼
var fileDropBtn = function() {
	$('.file-drop-group .file-delete').on('click',function(){
		var fileDrop= $(this).parents('.file-dropped');
		var fileDropUp= $(this).parents('.file-drop-group');
		fileDrop.remove();
		fileDropUp.removeClass('regist');
		
	})
};

// switch 버튼
var switchBtn = function(){
	$(document).on("click",".switch > .btn", function(){
		if(!$(this).hasClass("active")){
			$(this).addClass("active").attr("title","선택됨").siblings().removeClass("active").removeAttr("title")
		}
	})
}

// swiper 버튼
$(document).ready(function(){
	$('.swiper-type01 .btn.swiper').click(function(){
		if($(this).prop('checked')) {
			$(this).next('.swiper-label').children().text('활성화')
			console.log();
		} else {
			$(this).next('.swiper-label').children().text('비활성화')
		}
	});
});

// 인풋박스 - 삭제버튼
var inputValue = function(){

	var inputBox = $(".inp-box")
	var input = inputBox.find("input");
	var inputClear = inputBox.find(".btn.clear")
	input.on("input",function(){
		if($(this).siblings(".won").length){
			$(this).siblings(".won").hide().siblings(".clear").show();
		}else{
			$(this).siblings(".clear").show();
		}
	})

	inputClear.on("click",function(){
		$(this).siblings("input").val('');
		$(this).siblings(".won").show();
		$(this).hide().siblings("input").focus();
	})

	inputBox.on("mouseleave",function(){
		inputClear.hide();
		inputClear.siblings(".won").show();
	})
	
	inputClear.on("focusout",function(){
		$(this).hide();
		inputClear.siblings(".won").show();
	})

}

// 인풋박스 inp-type02 unit-type1 유형 케이스
var btnUnit = function () {
	$('.inp-type02.amount .inp-item input').on('input',function(){
		if(!$(this).val() == '') {
			// $(this).css('padding','0 3.8rem 0 2.6rem')
			$(this).css('padding-right','2.2rem')
		}
	}).on('focusout',function(){
		// $(this).css('padding','0 0 0 2.6rem')
		$(this).css('padding-right','0')
		$(this).siblings('.clear').css('display','none') // 추후 개선 예정
	});
};

// 인풋박스 inp-type02 account-type02 유형 케이스
var btnAccount_type02 = function () {
	$('.inp-type02.account-type02 .inp-item input').each(function(){
		$(this).on('input',function(){
			if(!$(this).val() == '') {
				$(this).css('padding-right','2.1rem')
			}
		}).on('focusout',function(){
			$(this).css('padding-right','0')
			$(this).siblings('.clear').css('display','none') // 추후 개선 예정
		})
	});
};

//즐겨찾기
var btnFavorite = function () {
	$('.btn.favorite').click(function(){
		$(this).toggleClass('on')
		if ($(this).attr('title') == '활성화') {
			$(this).attr('title','비활성화')
			$(this).children('.ui-blind').text('선택 비활성화')
		} else {
			$(this).attr('title','활성화')
			$(this).children('.ui-blind').text('선택 활성화')
		}
	});
};

// 정보박스 더보기 버튼 유형
var btnMore = function () {
	$('.btn-wrap.more-type .btn.btn-more').click(function(){
		$(this).parent().siblings('.list-shape').toggleClass('on')
		var btnMore_title = $(this).children().text()
		var title = '더보기 열기'
		var title_close = '더보기 닫기'
		if (btnMore_title == title) {
			$(this).children().text(title_close)
		} else {
			$(this).children().text(title)
		}
	});
};

// 플로팅 - 퀵 메뉴
var quickMenu = function(){
	$(".btn-wrap.floating .btn-quick").click(function(){
		var thisText = $(this).text()
		if($(this).hasClass("active")){
			$('html, body').removeAttr('style');
			$(this).children().text(thisText.replace("퀵메뉴 열기","퀵메뉴 닫기"));
			$(this).removeClass("active").closest(".btn-wrap.floating").removeClass("active");
		}else{
			console.log($(this).children())
			$('html, body').css('overflow','hidden');
			$(this).children().text(thisText.replace("퀵메뉴 닫기","퀵메뉴 열기"));
			$(this).addClass("active").closest(".btn-wrap.floating").addClass("active");
		}
	})
	
};

// 예약이체 스위치버튼 이벤트
var tranBtn = function(){
	$('.swiper-type01 .btn-trns01[type="checkbox"]').click(function(){
		if ($(this).is(':checked')) {
			$(this).parent().siblings('.reservation-transfer-area').css('display','block')
		} else {
			$(this).parent().siblings('.reservation-transfer-area').css('display','none')
		}
	});
}

// 인풋값 글자제한
// var maxLengthCheck = function(input) {
// 	if(input.value.length > input.maxLength) {
// 		input.value = input.value.slice(0, input.maxLength);
// 	}
// } 

// 예적금 - 상품가입 지역 검색 스크립트
var areaEvent = function() {
	$('.prd-mall-wrap .inp-wrap .inp-box.switch-type02 input').on('click',function(){
		var inp_area = $('.prd-mall-wrap .inp-wrap .inp-box.switch-type02').children('input').prop('checked',true)
		if (inp_area) {
			$('.prd-mall-wrap .inp-wrap .inp-box.switch-type02 input:checkbox[name="checktext01"]').prop('checked',false)
			$(this).prop('checked',true)
		}
	})
	
	$('.prd-mall-wrap .inp-area .btn-unfold').on('click',function(){
		$(this).parent().siblings('.zone-list-area').addClass('on')
	})
	$('.prd-mall-wrap .zone-list-area .btn-close').on('click',function(){
		$(this).closest('.zone-list-area').removeClass('on')
	})
	$('.prd-mall-wrap .zone-list-area > ul > li > .btn').on('click',function(){
		$('.zone-list-area > ul > li > .btn').removeClass('active')
		$(this).addClass('active')
	})
}

// 결재선
var apprEvent = function() {
	$('.approval-wrap .state-list ul li .btn').on('click',function(){
		$(this).parent().siblings().each(function(){
			$(this).children().removeClass('on');
		})
		$(this).addClass('on');
	})

	$('.paid-wrap .state-list ul li .btn').on('click',function(){
		$(this).parent().siblings().each(function(){
			$(this).children().removeClass('on');
		})
		$(this).addClass('on');
	})

	$('.popup-content.color-control .tab-group > .tab-heading-wrap > .tab-heading > li > a').on('click',function(){
		var case1 = $(this).hasClass('bgc-white')
		var case2 = $(this).hasClass('bgc-grey')
		if (case1) {
			$(this).closest('.popup-content').removeClass('bg-grey').addClass('bg-white')
			$(this).closest('.tab-heading-wrap').removeClass('bg-white')
		} else if (case2) {
			$(this).closest('.tab-heading-wrap').addClass('bg-white')
			$(this).closest('.popup-content').removeClass('bg-white').addClass('bg-grey')
		}
	});
}

// 승인결재이용안내 슬라이드
var apprGuideSlideHandler = function(){
	var swiper = new Swiper('.swiper-container.appr-guide-swiper', {
		slidesPerView:1.08,
		freeMode:true,
		spaceBetween:6,
	})
}