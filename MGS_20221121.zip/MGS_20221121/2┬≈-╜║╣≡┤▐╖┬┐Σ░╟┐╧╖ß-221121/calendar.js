// 달력 생성
function initCal(options){
    
    if(!options){
        options = {};
    }
    
    if(options.calTitle){
        calTitle = options.calTitle;
    }

    var calPopId = `${options.inputId}_calendarPop`;
    var inputDate = (options.inputDate ? options.inputDate : '' );
    var calTitle = '날짜 선택';
    var calHtml =  `<div class="ui-popup layer layer-calendar" id="${calPopId}" role="dialog" aria-labelledby="popTitle">
                        <div class="ui-popup-group" tabindex="-1">
                            <div class="popup-inner"><!-- fixed 클래스 추가시 하단 바텀 고정 -->
                                <div class="popup-header">
                                    <h3 class="h3 ui-popup-title" id="popTitle">${calTitle}</h3>
                                </div>
                                
                                <div class="ui-popup-body">
                                    <div class="ui-popup-con">
                                        <div class="ui-popup-inner">

                                            <!-- 캘린더 -->
                                            <div class="calendar-zone calendar-Default">
                                                <div class="text-group">
                                                    <input type="text" class="ui-calendar" placeholder="YYYY.MM.DD" value="${inputDate}" id="${calPopId}_input" readonly aria-label="${calTitle}">
                                                    <button type="button" class="btn ui-calendar" aria-expanded="false"><span class="ui-blind">${calTitle}</span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="popup-btn-wrap">
                                <button type="button" class="ui-pop-close"><span class="ui-blind">팝업닫기</span></button>
                            </div>
                        </div>
                    </div>`;
    
    //호출 시점에 지우고 새로 생성, 방어로직
    $(`#${calPopId}`).remove();
    $('body').append(calHtml);
    uiPopup.open(this,`#${calPopId}`);
    
    var calPopRemove = function(){
        $(`#${calPopId}`).remove();
    }
    
    var calPopOptions = {
        ariaHiddenArea:['#wrapper'],
        appendTarget:'.calendar-Default',
        selectDayFn:function(val){
            //날짜 선택 시 options.inputId에 선택한 날짜 값 세팅
            $(`#${options.inputId}`).val(val);
            $(`#${calPopId} button.ui-pop-close`).click();
            calPopRemove();

            var periodBtn = $(`#${options.inputId}`).parents('.calendar-box').find('[id*="divFTCal"]');
            if( periodBtn.length ){
                toggleClass('active', periodBtn.find('button'), this);
            }
            $(`#${options.inputId}`).change(); // 개발 - 날짜 입력 시점
        }
    }
    
    Object.assign(calPopOptions, options);
    /* 20221121 : 수정 */
    $(`#${calPopId}_input`).uiCal(calPopOptions, function(){
        //대량이체일 경우
        if( options.type == 'RV' ){
            var activeLength = $(`#${calPopId} .datepicker-grid td.day`).filter(function(){
                return !$(this).hasClass('disabled');
            }).length;
            // 해당 월에 예약할 수 있는 날짜가 없을 경우 다음달로 넘김
            if( activeLength == 0 ){
                $(`#${calPopId} .datepicker-month-next`).trigger('click');
            }
        }
    });
    /* //20221121 : 수정 */
    
    $(`#${calPopId} button.ui-pop-close`).click(function(){
        calPopRemove();
    });
}

//싱글 달력 | 대량이체달력 실행
function writeSearchConCal(options){
    
    if(!options){
        options = {};
    }
    
    //디폴트 옵션
    var uniqueKey   = (window.crypto.getRandomValues(new Uint32Array(1))[0] % 100) + 1; /* 20221121 : 수정 */
    var inputId     = `temporary${uniqueKey}`;
    var inputTitle  = '날짜 입력';
    var initDate    = ( options.initDate ? options.initDate : '');
    var typeClass   =  options.typeClass; 
    var require     = (options.require ? 'require' : '');
    var labelText   =  (options.labelText ? options.labelText : '날짜선택')

    if(options.inputId){
        inputId = options.inputId;
    }

    var searchConHtml =`<div class="calendar-box">
                            <div class="inp-group ${typeClass}"><!-- [D] 싱글 - single-type01, single-type02 / 더블 - double-type01, double-type02 -->
                                <div class="inp-item">
                                    <label for="${inputId}">
                                        <!-- [D] 상황별 클래스 추가) 필수 - require -->
                                        <span class="title ${require}">${labelText}<em class="require-msg">필수입력</em></span>
                                    </label>
                                    <input type="text" id="${inputId}" placeholder="YYYY.MM.DD" title="${inputTitle}" aria-label="${inputTitle}" readonly value="${initDate}">
                                    <button type="button" id="${inputId}_btnCal" class="btn calendar">
                                        <span class="ui-blind">날짜 선택</span>
                                    </button>
                                </div>
                            </div>
                        </div>`;
    
	// document.write(searchConHtml);	
    
    //퍼블 확인용 옵션
    if(options.pubhtml == 'pub'){
        document.write(searchConHtml);
    }else{
        if(options.targetId){
            //개발 - 캘린더 id값 지정
            $('#' + options.targetId).html(searchConHtml);
        } else {
            $('.calendar-wrap').html(searchConHtml);
        }
    }
    
    $(`#${inputId}_btnCal`).click(function(){
        if( $(`#${inputId}`).val() ){
            options.inputDate = $(`#${inputId}`).val();
        }
        initCal(options);
    });
}


//더블달력 실행
function writeSearchConFTCal(options){
    
    if(!options){
        options = {};
    }
    
    //디폴트 옵션
    var uniqueKey   = (window.crypto.getRandomValues(new Uint32Array(1))[0] % 100) + 1; /* 20221121 : 수정 */
    var fromInputId     = `temporary${uniqueKey}`;
    var toInputId        = `temporary${uniqueKey+1}`;
    var fromInputTitle  = '시작 날짜 입력';
    var toInputTitle    = '종료 날짜 입력';
    var fromInitDate    = ( options.from.initDate ? options.from.initDate : '');
    var toInitDate    = ( options.to.initDate ? options.to.initDate : '');
    var searchConBtnAreaHtml    = '';
    var btnType                 = (options.btnType == false ? false : [...options.btnType]);
    var typeClass   =  options.typeClass; 
    var require     = (options.require ? 'require' : '');
    var labelText   =  (options.labelText ? options.labelText : '날짜선택')

    if(options.from.inputId){
        fromInputId = options.from.inputId;
    }

    if(options.to.inputId){
        toInputId = options.to.inputId;
    }

    if( btnType.length ){
        var searchConBtnHtml = '';
        btnType.forEach(function(v){
            searchConBtnHtml += `<button type="button" class="btn switch-type02"><span>${v}</span></button>`;
        });
        searchConBtnAreaHtml = `<div class="btn-wrap switch" id="${fromInputId}_divFTCal">
                                    ${searchConBtnHtml}
                                </div>`;
    }

    var searchConHtml =` <div class="calendar-box">
                            ${searchConBtnAreaHtml}
                            <div class="inp-group ${typeClass}"><!-- [D] 싱글 - single-type01, single-type02 / 더블 - double-type01, double-type02 -->
                                <div class="inp-item">
                                    <label for="${fromInputId}">
                                        <!-- [D] 상황별 클래스 추가) 필수 - require -->
                                        <span class="title ${require}">${labelText}<em class="require-msg">필수입력</em></span>
                                    </label>
                                    <input type="text" id="${fromInputId}" placeholder="YYYY.MM.DD" title="${fromInputTitle}" aria-label="${fromInputTitle}" value="${fromInitDate}" readonly>
                                    <button type="button" id="${fromInputId}_btnCal" class="btn calendar" >
                                        <span class="ui-blind">날짜 선택</span>
                                    </button>
                                </div>
                                <div class="inp-item">
                                    <input type="text" id="${toInputId}" placeholder="YYYY.MM.DD" title="${toInputTitle}"  aria-label="${toInputTitle}" value="${toInitDate}" readonly>
                                    <button type="button" id="${toInputId}_btnCal" class="btn calendar" >
                                        <span class="ui-blind">날짜 선택</span>
                                    </button>
                                </div>
                            </div>
                        </div>`;

    
	// document.write(searchConHtml);	
    
    //퍼블 확인용 옵션
    if(options.pubhtml == "pub"){
        document.write(searchConHtml);	
    }else{
        if(options.targetId){
            //개발 - 캘린더 id값 지정
            $('#' + options.targetId).html(searchConHtml);
        } else {
            $('.calendar-wrap').html(searchConHtml);
        }
    }
	
    var fromOptions = Object.assign({},options);
    var toOptions = Object.assign({},options);
    Object.assign(fromOptions, options.from);
    Object.assign(toOptions, options.to);
    
    $(`#${fromInputId}_btnCal`).click(function(){
        if( $(`#${fromInputId}`).val() ){
            fromOptions.inputDate = $(`#${fromInputId}`).val();
        }
        initCal(fromOptions);
    });

    $(`#${toInputId}_btnCal`).click(function(){
        if( $(`#${toInputId}`).val() ){
            toOptions.inputDate = $(`#${toInputId}`).val();
        }
        initCal(toOptions);
    });

    $(`#${fromInputId}_divFTCal button`).off('click').on('click', function(){
        var txt = $(this).find('span').text();
        var future = txt.substring(txt.length -1) == '후' ? 'future' : '';
        if(future) txt = txt.substring(0, txt.length -1);
        var value = dateValueDB(txt, future);
        $(`#${fromInputId}`).val(value[0]);
        $(`#${toInputId}`).val(value[1]);
        toggleClass('active', `#${fromInputId}_divFTCal button`, this);
    });

    // 버튼 비활성화

    // - 버튼 스위치 btn-wrap 비활성화
    if($('.calendar-wrap').hasClass("disabled")){
        $('.calendar-wrap').filter(".disabled").find(`#${fromInputId}_divFTCal button`).attr("disabled",true);
        // - 캘린더 버튼(더블) 비활성화
        $('.calendar-wrap').filter(".disabled").find(`.${typeClass} .btn.calendar`).attr("disabled",true);
    }
    // - 캘린더 버튼 첫번째꺼 비활성화
    if($('.calendar-wrap').hasClass("first-disabled")){
        $('.calendar-wrap').filter(".first-disabled").find(`.${typeClass} .inp-item:first .btn.calendar`).attr("disabled",true);
    }

    // - 캘린더 버튼 두번째꺼 비활성화
    if($('.calendar-wrap').hasClass("last-disabled")){
        $('.calendar-wrap').filter(".last-disabled").find(`.${typeClass} .inp-item:last .btn.calendar`).attr("disabled",true);
    }


}

function toggleClass(className, target, self){
    $(target).removeClass(className);
    $(self).addClass(className);
}

function dateValueDB(val, type) {
	var date = new Date(),
		curYear = date.getFullYear(),
		curMonth = date.getMonth()+1,
		curDay = date.getDate(),
		fromDate = '',
		toDate = '',
		calcDate = null,
		calcDayNum = 0,
		calcMonthNum = 0,
		calcYearNum = 0;

    var sign = (type=='future' ? '+' : '-');
    var sign2 = (type=='future' ? '-' : '+');

	if(val=='오늘'){
		calcDayNum=0;
	}
    else if(val=='어제'){
		calcDayNum=Number(sign + 1);
	}
    else if(val=='3일' || val=='3일전'){
		calcDayNum=Number(sign + 2);
	} else if(val=='1주일' || val=='1주일전'){
		calcDayNum=Number(sign + 6);
	} else if(val=='1개월' || val=='1개월전'){
        calcMonthNum=Number(sign + 1);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='3개월' || val=='3개월전'){
		calcMonthNum=Number(sign + 3);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='6개월' || val=='6개월전'){
		calcMonthNum=Number(sign + 6);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='1년' || val=='1년전'){
		calcYearNum=Number(sign + 1);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='2년' || val=='2년전' ){
		calcYearNum=Number(sign + 2);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='3년' || val=='3년전' ){
		calcYearNum=Number(sign + 3);
		calcDayNum=Number(sign2 + 1);
    } else if(val=='4년' || val=='4년전' ){
		calcYearNum=Number(sign + 4);
		calcDayNum=Number(sign2 + 1);
    } else if(val=='5년' || val=='5년전' ){
		calcYearNum=Number(sign + 5);
		calcDayNum=Number(sign2 + 1);
	} else if(val=='전월' ){
		calcMonthNum=-1;
		curDay=1;
		date = new Date(date.getYear(), date.getMonth(), 0);
	} else if(val=='당월' ){
		curDay=1;
		date = new Date(date.getYear(), date.getMonth()+1, 0);
	} 

    var toChkMonth = ((date.getMonth()+1)<10)?'0'+(date.getMonth()+1):(date.getMonth()+1),
        toChkDate = (date.getDate()<10)?'0'+date.getDate():date.getDate();
        calcDate = new Date(curYear+calcYearNum, curMonth+calcMonthNum-1, curDay+calcDayNum, 0, 0);
        var fromChkMonth = (calcDate.getMonth()+1<10)?'0'+(calcDate.getMonth()+1):calcDate.getMonth()+1,
        fromChkDate = (calcDate.getDate()<10)?'0'+calcDate.getDate():calcDate.getDate();
		fromDate = calcDate.getFullYear()+'.'+fromChkMonth+'.'+fromChkDate;
		toDate = curYear+'.'+toChkMonth+'.'+toChkDate;

		return type=='future' ? [toDate,fromDate] : [fromDate,toDate];
};