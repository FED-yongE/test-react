'use strict';

// 기본유형
// $('#date0').uiCal({ariaHiddenArea:['.wrapper']});

// 기본유형(이전날짜 선택 안되도록)
// $('#date1').uiCal({ariaHiddenArea:['.wrapper'], beforeSelect:false});

// 캘린더(from ~ to)
// UI_Cal.Datepicker.fromTo({ariaHiddenArea:'.wrapper', fromTarget:'#from-date0', toTarget:'#to-date0'});

// 캘린더(from ~ to) (이전날짜 선택 안되도록)
// UI_Cal.Datepicker.fromTo({ariaHiddenArea:'.wrapper', fromTarget:'#from-date1', toTarget:'#to-date1', beforeSelect:false});

// 캘린더(select) 
// $('#dateSelct0').uiCal({ariaHiddenArea:['.wrapper'], selectBool:true});

// 캘린더(select : from ~ to)
// UI_Cal.Datepicker.fromTo({ariaHiddenArea:'.wrapper', fromTarget:'#fromDateSelect1', toTarget:'#toDateSelect1', selectBool:true});

// 캘린더 대상 타겟에 붙이기 appendTarget
// $('#dateAppend0').uiCal({ariaHiddenArea:['.wrapper'], selectBool:true, appendTarget:'.calendar-view-group'});


// 캘린더(select) html샘플
// <div class="text-group">
// 	<input type="text" class="default calendar" placeholder="YYYY-MM-DD" id="dateSelct0" readonly aria-label="날짜 선택">
// 	<button type="button" class="btn calendar" aria-expanded="false"><span class="ui-blind">날짜 선택</span></button>
// 	<!-- 년 -->
// 	<select name="" id="" class="default small noline noshadow none calendar-year-select">
// 		<option value="2016">2016</option>
// 		<option value="2017">2017</option>
// 		<option value="2018">2018</option>
// 		<option value="2019">2019</option>
// 		<option value="2020">2020</option>
// 		<option value="2021">2021</option>
// 		<option value="2022">2022</option>
// 		<option value="2023">2023</option>
// 		<option value="2024">2024</option>
// 		<option value="2025">2025</option>
// 		<option value="2026">2026</option>
// 	</select>
// 	<!-- 월 -->
// 	<select name="" id="" class="default small noline noshadow none calendar-month-select">
// 		<option value="1">1</option>
// 		<option value="2">2</option>
// 		<option value="3">3</option>
// 		<option value="4">4</option>
// 		<option value="5">5</option>
// 		<option value="6">6</option>
// 		<option value="7">7</option>
// 		<option value="8">8</option>
// 		<option value="9">9</option>
// 		<option value="10">10</option>
// 		<option value="11">11</option>
// 		<option value="12">12</option>
// 	</select>
// </div>

// 캘린더 두개 (FROM ~ TO)
// html ======================================
// <div class="text-group w-size245">
// 	<input type="text" class="default ui-calendar fromto-all" placeholder="YYYY.MM.DD ~ YYYY.MM.DD" id="date0" readonly="" aria-label="날짜 선택">
// 	<button type="button" class="btn ui-calendar" onclick="uiPopup.open(this,'#calendarPop'); calendarResetHandler();"><span class="ui-blind">날짜 선택</span></button>
// </div>
// <div class="calendar-group">
// 	<div class="title">시작일</div>
// 	<div class="text-group size-medium">
// 		<input type="text" class="default ui-calendar from-day" placeholder="YYYY.MM.DD" id="from-date0" readonly="" aria-label="시작일">
// 		<button type="button" class="btn ui-calendar ui-blind" aria-expanded="false" aria-hidden="true"><span class="ui-blind">시작일 선택</span></button>
// 	</div>
// 	<div class="title">~ 종료일</div>
// 	<div class="text-group size-medium">
// 		<input type="text" class="default ui-calendar to-day" placeholder="YYYY.MM.DD" id="to-date0" readonly="" aria-label="종료일">
// 		<button type="button" class="btn ui-calendar ui-blind" aria-expanded="false" aria-hidden="true"><span class="ui-blind">종료일 선택</span></button>
// 	</div>
// </div>
// <script> ====================================
// if($('.from-cal .cal-area').find('.datepicker-calendar').length==0){
// 	$('#from-date0').uiCal({ariaHiddenArea:['.wrapper'], appendTarget:'.from-cal .cal-area', afterSelect:false, weekendClickable:true,
// 		selectDayFn: function(val){
// 			$('#to-date0').attr('data-fromdate', val);
// 			$('#to-date0').trigger('change');
// 			calendarSelectNextBtnHandler();
// 		}
// 	});
// }

// // today calendar
// if($('.to-cal .cal-area').find('.datepicker-calendar').length==0){
// 	$('#to-date0').uiCal({ariaHiddenArea:['.wrapper'], appendTarget:'.to-cal .cal-area', afterSelect:false, weekendClickable:true,
// 		selectDayFn: function(val){
// 			$('#from-date0').attr('data-todate', val);
// 			$('#from-date0').trigger('change');
// 			calendarSelectNextBtnHandler();
// 		}
// 	});
// }

// from input, to input change
// $('#from-date0 , #to-date0').on('change', function(){
// 	calendarSelectNextBtnHandler();
// });
// 
// // button change text
// function calendarSelectNextBtnHandler() {
// 	if($('#from-date0').val().length==0){
// 		$('.btn-select-last').find('.ui-text').text('시작일을 선택하세요');
// 	}
// 	if($('#to-date0').val().length==0){
// 		$('.btn-select-last').find('.ui-text').text('종료일을 선택하세요');
// 	}
// 	if($('#from-date0').val().length && $('#to-date0').val().length){
// 		$('.btn-select-last').addClass('close').removeAttr('disabled').find('.ui-text').text('선택완료');
// 	}
// }
// 
// // selected day and button click for change page's input value 
// $('.btn-select-last').on('click', function(){
// 	$('#date0').val($('#from-date0').val()+' ~ '+$('#to-date0').val());
// });
// 
// // calendar reset : 새로 열었을 때 위치 초기화
// function calendarResetHandler() {
// 	if($('.fromto-all').val().length==0){
// 		$('#from-date0').val('');
// 		$('#to-date0').val('');
// 		$('#from-date0').attr('data-fromdate','');
// 		$('#from-date0').attr('data-todate','');
// 		$('#to-date0').attr('data-fromdate','');
// 		$('#to-date0').attr('data-todate','');
// 		$('.btn-select-last').removeClass('close').attr('disabled',true);
// 		$('.calendar-select-group .rdo-btn').prop('checked', false);
// 		$('#from-date0').trigger('resetkeyboard');
// 		$('#to-date0').trigger('resetkeyboard');	
// 	}else{
// 		
// 		var str = $('input.fromto-all').val().replace(' ~ ','');
// 		$('#from-date0').attr('data-date', str.substr(0,10)).val(str.substr(0,10));
// 		$('#to-date0').attr('data-date', str.substr(10,10)).val(str.substr(10,10));
// 		$('#from-date0').trigger('change');
// 		$('#to-date0').trigger('change');
// 		$('#from-date0').attr('data-fromdate', $('#from-date0').val());
// 		$('#from-date0').attr('data-todate', $('#to-date0').val());
// 		$('#to-date0').attr('data-fromdate', $('#from-date0').val());
// 		$('#to-date0').attr('data-todate', $('#to-date0').val());
// 		$('#from-date0').trigger('addkeyboard');
// 		$('#to-date0').trigger('addkeyboard');	
// 	}
// 	$('#from-date0').trigger('reset');
// 	$('#to-date0').trigger('reset');
// }
// </script>


var UI_Cal = {
	Datepicker : {
		DEFAULTS : {
			yearText : '년',
			monthText : '월',
			dayText : '일',
			monthsFull : ['1 월', '2 월', '3 월', '4 월', '5 월', '6 월', '7 월', '8 월', '9 월', '10 월', '11 월', '12 월'],
			weekdaysShort : ['일', '월', '화', '수', '목', '금', '토'],
			weekdaysFull : ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
			format : 'yyyy.mm.dd', //'yyyy-mm-dd' or 'yyyy.mm.dd' (2type)
			modal : false, // 모달 팝업시
			selectYear : null, // year select 사용시
			selectMonth : null, // month select 사용시
			currentDate : null, // 외부에서 넣은 날짜
			fromToTarget : null, // from ~ to 용
			ariaHiddenArea : null, // 접근성
			beforeSelect : true, // 이전 날짜 선택 Boolean
			afterSelect : true, // 다음 날짜 선택 Boolean
			fromToBoolean : false, // from ~ to의 존재 여부
			fromTarget : null, // from 타겟
			toTarget : null, // to 타겟
			fromDate : null, // from date 인풋박스 value
			toDate : null, // to date 인풋박스 value
			selectBool : false, // 년, 월 셀렉트 박스
			appendTarget : null, // append 될 타겟
			todaySelect : true, // 오늘 날짜 선택 안되도록
			selectDayFn : null, // 날짜 선택시 호출 함수
			firstChkDayFn : null, // 이체 날짜 선택 시작일
			gapMonth : null, // 오늘 날짜 부터 gapMonth만큼만 선택 되도록
			weekendClickable : false // 주말 클릭 안되도록(deault : false)
		},
		common : {
			prototypeInit : function() {
				UI_Cal.Datepicker.initializePrototypeHandler();
			}
		},
		datepickerCalendar : [
			'<div class="datepicker-calendar default" id="datepicker-calendar-CALENDARID" aria-hidden="false">',
			'	<div class="datepicker-month-wrap datepicker-flex">',
			'		<button type="button" class="datepicker-month-fast-prev pull-left" title="이전년도"><span class="glyphicon glypicon-backward"></span></button>',
			'		<div id="datepicker-year-CALENDARID" class="datepicker-year">July 2015</div>',
			'		<button type="button" class="datepicker-month-fast-next pull-right" title="다음년도"><span class="glyphicon glyphicon-forward"></span></button>',
			'		<button type="button" class="datepicker-month-prev pull-left" title="이전달"><span class="glyphicon glyphicon-triangle-left"></span></button>',
			'		<div id="datepicker-month-CALENDARID" class="datepicker-month">July 2015</div>',
			'		<button type="button" class="datepicker-month-next pull-right" title="다음달"><span class="glyphicon glyphicon-triangle-right"></span></button>',
			'		<button type="button" class="datepicker-today"><span class="txt">오늘</span></button>',
			'	</div>',
			'	<table class="datepicker-grid">',
			'		<caption>날짜 선택 캘린더</caption>',
			'		<thead>',
			'			<tr class="datepicker-weekdays">',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Sunday">Sun</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Monday">Mon</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Tuesday">Tue</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Wednesday">Wed</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Thursday">Thu</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Friday">Fri</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Saturday">Sat</abbr></th>',
			'			</tr>',
			'		</thead>',
			'		<tbody role="presentation">',
			'			<tr>',
			'				<td id="datepicker-err-msg-CALENDARID" colspan="7">Javascript must be enabled</td>',
			'			</tr>',
			'		</tbody>',
			'	</table>',
			// '	<div class="datepicker-close-wrap">',
			// '		<button class="datepicker-close" id="datepicker-close-CALENDARID" title="달력닫기" aria-label="달력닫기">&#10006;</button>',
			// '	</div>',
			'</div>'
		],
		datepickerSelectCalendar : [
			'<div class="datepicker-calendar default" id="datepicker-calendar-CALENDARID" aria-hidden="false">',
			'	<div class="datepicker-month-wrap datepicker-flex">',
			'		<div class="calendar-select-year-group">',
			'			<span>년도 붙이기</span>',
			'		</div>',
			'		<div class="calendar-select-month-group">',
			'			<span>월 붙이기</span>',
			'		</div>',
			'		<button type="button" class="datepicker-today"><span class="txt">오늘</span></button>',
			// '		<div id="datepicker-month-CALENDARID" class="datepicker-month" role="heading" aria-live="assertive" aria-atomic="true">July 2015</div>',
			'	</div>',
			'	<table class="datepicker-grid">',
			'		<caption>날짜 선택 캘린더</caption>',
			'		<thead role="presentation">',
			'			<tr class="datepicker-weekdays" role="row">',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Sunday">Sun</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Monday">Mon</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Tuesday">Tue</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Wednesday">Wed</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Thursday">Thu</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Friday">Fri</abbr></th>',
			'				<th scope="col" id="day0-header-CALENDARID" class="datepicker-day"><abbr title="Saturday">Sat</abbr></th>',
			'			</tr>',
			'		</thead>',
			'		<tbody role="presentation">',
			'			<tr>',
			'				<td id="datepicker-err-msg-CALENDARID" colspan="7">Javascript must be enabled</td>',
			'			</tr>',
			'		</tbody>',
			'	</table>',
			// '	<div class="datepicker-close-wrap">',
			// '		<button class="datepicker-close" id="datepicker-close-CALENDARID" title="달력닫기" aria-label="달력닫기">&#10006;</button>',
			// '	</div>',
			'</div>'
		],
		calBlackBg : '<div class="calendar-black-bg on" tabindex="-1"></div>',
		dayEmpty : '<td class="empty"><span class="day-txt"></span></td>',
		dayAddTd : '<td id="cell1-CALENDARID" class="day selectable" data-value="0" header="day0-header-date"><button type="button" class="day-txt" title="선택가능">1</button></td>',
		todayAdd : '<span class="today-txt">오늘</span>',
		monthAddTd : '<td id="cell1-CALENDARID" class="month selectable" data-value="0" title="January 2019" role="gridcell"><Jan></div>',
		captionEl : '<caption>예약이체 실행일 선택 캘린더, 오늘은 예약이체시간을 정할 수 없습니다. 예약이체일(이체실행일자)는 이체등록일 기준 3개월후까지, 공휴일(토요일 포함)을 제외한 영업일로 등록할 수 있습니다. 예약이체일의 최대 등록 건수는 1일 10건(1회 5건)입니다. 예약이체는 예약이체등록일(당일)의 1일 이체한도에 포함됩니다.</caption>',
		// captionDF : '<caption>날짜 선택 캘린더</caption>',

		initialize : function(target, options, callback) {  /* 20221121 : 수정 */
			var self = this;

			this.mobile = null;
			this.target = target;
			this.opt = $.extend({}, UI_Cal.Datepicker.DEFAULTS, options);
			this.today = self.serverDate(); // 이동한 날짜
			this.date = self.today; // 선택한 날짜
			this.realToday = self.today;
			this.selectToday = self.today;
			this.gapDate = null;
			this.cal = null;
			this.calbg = null;
			this.btnName = null;
			this.prevVal = '';
			this.curYearMonth = null;
			this.tbCalendar = null;
			this.tbCalendarYM = null;
			this.isKeyboard = null;
			this.fromToBtnName = '';
			this.dayNum = 1;
			this.uaSet(); // user agent
			this.init(); // 실행

			/* 20221121 : 추가 */
			if( typeof(callback) == 'function' ){
				callback();
			}
			/* //20221121 : 수정 */
		},

		initializePrototypeHandler : function() {
			// 외부에서 넣을 날짜가 있으면, 외부 날짜 적용
			UI_Cal.Datepicker.initialize.prototype.serverDate = function() {
				return this.opt.currentDate == null ? this.getCurDate() : this.outCurDate(this.opt.currentDate);
			};

			// 오늘 날짜
			UI_Cal.Datepicker.initialize.prototype.getCurDate = function(val) {
				if(val == undefined) {
					return new Date();
				} else if(typeof val === 'object') {
					if(val.legnth == 5) {
						return new Date(parseInt(val[0]), parseInt(val[1]), parseInt(val[2]), parseInt(val[3]), parseInt(val[4]));
					} else {
						return new Date(parseInt(val[0]), parseInt(val[1]), parseInt(val[2]), 0, 0);
					}
				}
			};

			// 날짜 형식 체크
			UI_Cal.Datepicker.initialize.prototype.outCurDate = function(val) {
				if(typeof val === 'object') {
					var arrOfDate = val.split('-');

					if(arrOfDate.length == 3) {
						if(parseFloat(arrOfDate[0]) != NaN && parseFloat(arrOfDate[1]) != NaN && parseFloat(arrOfDate[2]) != NaN) {
							return new Date(parseFloat(arrOfDate[0]), parseFloat(arrOfDate[1]) - 1, parseFloat(arrOfDate[2]));
						} else {
							return new Date();
						}
					} else {
						return new Date();
					}
				}
			};

			// 날짜 형식
			UI_Cal.Datepicker.initialize.prototype.splitDate = function(val) {
				if(typeof val === 'string' || val === undefined) {
					switch(val) {
						case 'point' :
							if(this.opt.format == 'yyyy-mm-dd') {
								return '-';
							} else if(this.opt.format == 'yyyy.mm.dd') {
								return '.';
							}
							break;
						default :
							if(this.opt.format == 'yyyy-mm-dd') {
								return this.target.val().split('-');
							} else if(this.opt.format == 'yyyy.mm.dd') {
								return this.target.val().split('.');
							}
					}
				} else if(typeof val === 'object') {
					if(this.opt.yearMonthView) {
						var varSplice = val;
						varSplice.splice(varSplice.length - 1, 1);
						if(this.opt.format == 'yyyy-mm-dd') {
							return varSplice.join('-');
						} else if(this.opt.format == 'yyyy.mm.dd') {
							return varSplice.join('.');
						}
					} else {
						if(this.opt.format == 'yyyy-mm-dd') {
							return val.join('-');
						} else if(this.opt.format == 'yyyy.mm.dd') {
							return val.join('.');
						}
					}
				}
			};

			// 숫자가 true , false 체크
			UI_Cal.Datepicker.initialize.prototype.numCheck = function(val) {
				if(typeof val === 'object') {
					var checkYear = parseFloat(val[0]);
					var checkMonth = parseFloat(val[1]);
					var checkDay = parseFloat(val[2]);
					if(checkYear != NaN && checkMonth != NaN && checkDay != NaN) {
						return true;
					} else {
						return false;
					}
				}
			};

			// 10이하 일때 앞에 0붙이기
			UI_Cal.Datepicker.initialize.prototype.numSet = function(val) {
				return val < 10 ? '0' + val : val;
			};

			// user agent 체크
			UI_Cal.Datepicker.initialize.prototype.uaSet = function() {
				var ua = navigator.userAgent.toLowerCase();
				if(ua.search("android") > -1) {
					this.mobile = 'android';
				}
				// IOS
				if((ua.search("iphone") > -1) || (ua.search("ipod") > -1) || (ua.search("ipad") > -1)) {
					this.mobile = 'ios';
				}
			};

			UI_Cal.Datepicker.initialize.prototype.replaceAll = function(target, searchStr, replaceStr) {
				var temp = target;
				while(temp.indexOf(searchStr) != -1) {
					temp = temp.replace(searchStr, replaceStr);
				}
				return temp;
			};

			// ====================================================================================================================
			// ====================================================================================================================
			// 실행
			// ====================================================================================================================
			// ====================================================================================================================
			UI_Cal.Datepicker.initialize.prototype.init = function() {
				var self = this;
				self.target.next('a, button').on('click', function(e) {
					e.preventDefault();

					if($(this).attr('aria-expanded') == 'false') {
						// from ~ to : from 값이 없을 때 알럿 문구
						if($(this).hasClass('to')) {
							self.fromToBtnName = 'to';
							if($(self.opt.fromTarget).val() == '' || $(self.opt.fromTarget).val().length < 10) {
								alert('from 날짜부터 선택해 주세요.');
								return false;
							}
						} else {
							self.fromToBtnName = 'from';
						}
						/*  소스보안약점(적절하지 않은 난수 값 상) */
						self.prevVal = self.target.val();
						$(this).focus();

						var array = new Uint32Array(1);
						window.crypto.getRandomValues(array);
						var secureNumber = (array[0] % 100000) + 1;
						//랜덤넘버 221027 
						self.id = self.target.attr('id') || 'datepicker-' + secureNumber;
						self.arrOfDateFn();

					} else {
						self.cal.find('.datepicker-close').trigger('click');
					}
					
				});

				self.target.on('click', function(e) {
					$(this).next('a, button').trigger('click');
				});

				if(self.opt.appendTarget != null) {
					self.target.next('a, button').trigger('click');
					$('.datepicker-calendar').addClass('views');
				}

				// fromday 선택시
				self.target.off('change').on('change', function() {
					self.btnName = '';
					self.opt.isKeyboard = 'Keyboard';
					if(self.target.hasClass('from-day')) {
						if(self.target.attr('data-date') != null) {
							var startDateArr = self.target.attr('data-date').split(self.splitDate('point'));
							self.date = self.today = self.selectToday = self.getCurDate([startDateArr[0], parseInt(startDateArr[1]) - 1, startDateArr[2]]);
							self.target.addClass('selected-day');
							self.target.val(self.target.attr('data-date'));
						}
					}
					if(self.target.hasClass('to-day')) {
						if(self.target.attr('data-date') != null) {
							var startDateArr = self.target.attr('data-date').split(self.splitDate('point'));
							self.date = self.today = self.selectToday = self.getCurDate([startDateArr[0], parseInt(startDateArr[1]) - 1, startDateArr[2]]);
						}
					}

					var startDateArr = self.target.attr('data-date').split(self.splitDate('point'));
					self.date = self.today = self.selectToday = self.getCurDate([startDateArr[0], parseInt(startDateArr[1]) - 1, startDateArr[2]]);
					self.addCalendar();
				});

				self.target.off('reset').on('reset', function() {
					self.btnName = '';
					self.today = self.date;
					self.addCalendar();
				});

				self.target.off('resetkeyboard').on('resetkeyboard', function() {
					self.btnName = '';
					self.today = self.date = self.realToday;
					self.opt.isKeyboard = null;
					self.target.removeAttr('data-fromdate');
					self.target.removeAttr('data-todate');
					self.addCalendar();
				});
				self.target.off('addkeyboard').on('addkeyboard', function() {
					self.btnName = '';
					self.opt.isKeyboard = 'Keyboard';
				});
			};

			UI_Cal.Datepicker.initialize.prototype.arrOfDateFn = function() {
				var self = this;
				if(self.target.val() == '') {
					// input 박스에 value 값이 없을 때
					self.today = self.serverDate();

					// self.today = self.getCurDate([2021,3,30]);
					self.date = self.today;
					self.realToday = self.today;
					self.selectToday = self.today;

					// input 에 data-date 값이 있을 경우
					if(self.target.attr('data-date') != null) {
						var startDateArr = self.target.attr('data-date').split(self.splitDate('point'));
						self.date = self.today = self.getCurDate([startDateArr[0], parseInt(startDateArr[1]) - 1, startDateArr[2]]);
						self.target.addClass('selected-day');
						self.target.val(self.target.attr('data-date'));
					}

					// 오늘 날짜 선택이 불가능 일때
					if(!self.opt.todaySelect) {
						if(self.today.getDay() + 1 == 6) self.dayNum = 3;
						self.date = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), self.today.getDate() + self.dayNum]);
						self.today = self.date;
						self.selectToday = self.date;
					}
					if(self.opt.firstChkDayFn != null) {
						var selectTodayStr = self.selectToday.getFullYear() + '.' + self.numSet(self.selectToday.getMonth() + 1) + '.' + self.numSet(self.selectToday.getDate());
						self.opt.firstChkDayFn(selectTodayStr);
					}
					// from ~ to
					if(self.fromToBtnName == 'to') {
						var startDateArr = $(self.opt.fromTarget).val().split(self.splitDate('point'));
						self.today = self.getCurDate([parseFloat(startDateArr[0]), parseFloat(startDateArr[1]) - 1, parseFloat(startDateArr[2])]);
						self.date = self.today;
					}
				} else if(self.target.val().length == 10) {
					// input 박스에 value 값이 있을 때
					var arrOfDate = [], txt = null;
					arrOfDate = self.splitDate();
					if(arrOfDate.length == 3) {
						// 년, 월, 일이 다 있을 경우
						var isYear = parseFloat(arrOfDate[0]),
							isMonth = parseFloat(arrOfDate[1]),
							isDay = parseFloat(arrOfDate[2]);
						if(self.numCheck(arrOfDate)) {
							// 년, 월, 일이 숫자 였을 경우
							if(isMonth - 1 < 12 && isMonth - 1 >= 0) {
								var totalDate = (self.getCurDate([isYear, isMonth, 0])).getDate();
								if(isDay > 0 && isDay <= totalDate) {
									// 일이 월의 총 일 수 안에 있을 때
									self.today = self.getCurDate([isYear, isMonth - 1, isDay]);
									self.date = self.today;
								} else {
									// 일이 월의 총 일수를 벗어 났을 때
									self.currentView();
								}
							} else {
								// 월이 0~11 아닐때
								self.currentView();
							}
						} else {
							// 년, 월, 일 중에 숫자가 아닐 경우
							self.currentView();
						}
					} else {
						// 년, 월, 일 중에 하나라도 없을 경우
						self.currentView();
					}
				} else {
					// input 박스에 value 값이 정상적이지 않을 때
					self.currentView();
				}

				if(self.opt.ariaHiddenArea != null) {
					if(typeof self.opt.ariaHiddenArea == 'object') {
						for(var a = 0; a < self.opt.ariaHiddenArea.length; a++) {
							$(self.opt.ariaHiddenArea[a]).attr('aria-hidden', 'true');
						}

					} else if(typeof self.opt.ariaHiddenArea == 'string') {
						$(self.opt.ariaHiddenArea).attr('aria-hidden', 'true');
					}
				}

				// 캘린더 붙이기
				self.addCalendar();
			};

			UI_Cal.Datepicker.initialize.prototype.currentView = function() {
				var self = this,
					startDate = null,
					startDateArr = null,
					isPoint,
					curYear,
					curMonth,
					curDate;

				isPoint = self.splitDate('point');
				if(target.attr('data-date') == undefined) {
					self.today = self.serverDate();
					self.date = self.today;
					curYear = self.date.getFullYear();
					curMonth = self.numSet(self.date.getMonth() + 1);
					curDate = self.numSet(self.date.getDate());
					startDateArr = [curYear, curMonth, curDate];
				} else {
					startDate = target.attr('data-date');
					startDateArr = startDate.split(isPoint);
					self.today = self.getCurDate([parseFloat(startDateArr[0]), parseFloat(startDateArr[1]) - 1, parseFloat(startDateArr[2])]);
					self.date = self.today;
				}
				self.val(self.splitDate(startDateArr));
			};

			// ===================================================
			// 캘린더 붙이기
			// ===================================================
			UI_Cal.Datepicker.initialize.prototype.addCalendar = function() {
				var self = this;
				self.target.next('a, button').attr('aria-expanded', 'true');

				// append 된 캘린더가 없을때
				if(self.cal == null) {
					var calendar = (!self.opt.selectBool) ? UI_Cal.Datepicker.datepickerCalendar.join('\n') : UI_Cal.Datepicker.datepickerSelectCalendar.join('\n');
					calendar = calendar.replace(/CALENDARID/g, self.id + '');

					if(self.opt.appendTarget == null) {
						$(self.target).parent().append(calendar);
					} else {
						$(self.opt.appendTarget).html('').append(calendar);
					}
					self.cal = $('#datepicker-calendar-' + self.id);
					self.calbg = $('.calendar-black-bg');
					
					// 요일 텍스트 설정
					var tbThead = $('#datepicker-calendar-' + self.id).find('table.datepicker-grid thead');
					for(var a = 0; a < 7; a++) {
						// tbThead.find('th').eq(a).attr('aria-label', self.opt.weekdaysFull[a]);
						tbThead.find('th').eq(a).find('abbr').attr('title', self.opt.weekdaysFull[a]).text(self.opt.weekdaysShort[a]);
					}
					if(self.target.hasClass('from-day')) {
						self.target.attr('data-fromdate', self.realToday.getFullYear() + '.' + ((self.realToday.getMonth() + 1) < 10 ? '0' + (self.realToday.getMonth() + 1) : (self.realToday.getMonth() + 1)) + '.' + (self.realToday.getDate() < 10 ? '0' + self.realToday.getDate() : self.realToday.getDate()));
					}
					if(self.target.hasClass('to-day')) {
						self.target.attr('data-todate', self.realToday.getFullYear() + '.' + ((self.realToday.getMonth() + 1) < 10 ? '0' + (self.realToday.getMonth() + 1) : (self.realToday.getMonth() + 1)) + '.' + (self.realToday.getDate() < 10 ? '0' + self.realToday.getDate() : self.realToday.getDate()));
					}
					// tbThead.find('table thead').before(UI_Cal.Datepicker.captionDF);
				}

				// 캘린더 포커스 이동
				self.cal.removeAttr('style').attr('aria-hidden', 'false');
				$(self.target).parent().parent().css('position', 'relative');

				// 캘린더 위치 잡기
				var value = 0;
				$('#datepicker-calendar-' + self.id).addClass('after').css('left', value + 'px');
				var winWidth = $(window).innerWidth();
				var calWidth = $('#datepicker-calendar-' + self.id).outerWidth();
				var calLeft = $('#datepicker-calendar-' + self.id).offset().left;
				if(winWidth < calLeft + calWidth) {
					var valueGap = winWidth - (calLeft + calWidth);
					$('#datepicker-calendar-' + self.id).css({'left' : valueGap + 'px'});
				}
				if(self.opt.appendTarget != null) {
					$('#datepicker-calendar-' + self.id).css({'top' : 0, 'position' : 'relative'});
					// $('#datepicker-calendar-' + self.id).find('.datepicker-close').css('display', 'none');
					$('#datepicker-calendar-' + self.id).find('.datepicker-month-wrap').css('padding-right', '0');
				} else {
					$('#datepicker-calendar-' + self.id).css({'top' : $(self.target).outerHeight() + 'px'});
				}

				// 년, 월 보기
				self.yearMonthViewAddDayHandler();
			};

			// 이전년도, 이전달, 다음달, 다음년도 버튼에 접근성 : title 넣기
			UI_Cal.Datepicker.initialize.prototype.yearMonthViewAddDayHandler = function() {
				var self = this,
					currentYear = parseFloat(self.today.getFullYear()),
					currentMonth = parseFloat(self.today.getMonth() + 1),
					prevYear = parseFloat(self.getCurDate([currentYear - 1, currentMonth, 0]).getFullYear()),
					nextYear = parseFloat(self.getCurDate([currentYear + 1, currentMonth, 0]).getFullYear()),
					prevMonth = self.getCurDate([currentYear, parseFloat(self.today.getMonth()) - 1, 1]),
					nextMonth = self.getCurDate([currentYear, parseFloat(self.today.getMonth()) + 1, 1]);

				// Year, month   SELECT 일 경우
				if(self.opt.selectBool) {
					var yearEl, monthEl;

					if(self.opt.appendTarget != null) {
						yearEl = $(self.opt.appendTarget).find('.calendar-year-select').removeClass('none');
						monthEl = $(self.opt.appendTarget).find('.calendar-month-select').removeClass('none');
					} else {
						yearEl = self.target.parent().find('.calendar-year-select').removeClass('none');
						monthEl = self.target.parent().find('.calendar-month-select').removeClass('none');
					}

					self.cal.find('.calendar-select-year-group').html('').append(yearEl);
					self.cal.find('.calendar-select-month-group').html('').append(monthEl);

					self.cal.find('.calendar-year-select').val(self.today.getFullYear());
					self.cal.find('.calendar-month-select').val(self.today.getMonth() + 1);
					// Year, month  좌우 버튼 일 경우
				} else {
					self.cal.find('.datepicker-month-fast-prev').attr('title', prevYear + self.opt.yearText + ' ' + currentMonth + self.opt.monthText + ' 이동');
					self.cal.find('.datepicker-month-prev').attr('title', prevMonth.getFullYear() + self.opt.yearText + ' ' + (parseFloat(prevMonth.getMonth()) + 1) + self.opt.monthText + ' 이동');
					self.cal.find('.datepicker-month-fast-next').attr('title', nextYear + self.opt.yearText + ' ' + currentMonth + self.opt.monthText + ' 이동');
					self.cal.find('.datepicker-month-next').attr('title', nextMonth.getFullYear() + self.opt.yearText + ' ' + (parseFloat(nextMonth.getMonth()) + 1) + self.opt.monthText + ' 이동');
				}

				// 캘린더의 년, 월 표시
				self.curYearMonth = self.today.getFullYear() + self.opt.yearText + ' ' + self.opt.monthsFull[self.today.getMonth()];
				self.curYear = self.today.getFullYear() + ' ' + self.opt.yearText;
				self.curMonth = self.opt.monthsFull[self.today.getMonth()];

				// 캘린더 테이블 아이디 붙이기
				self.tbCalendar = $('#datepicker-calendar-' + self.id).find('table.datepicker-grid');
				self.tbCalendarYM = $('#datepicker-calendar-' + self.id).find('#datepicker-month-' + self.id);
				self.tbCalendarYear = $('#datepicker-calendar-' + self.id).find('#datepicker-year-' + self.id);
				self.tbCalendarMonth = $('#datepicker-calendar-' + self.id).find('#datepicker-month-' + self.id);

				self.tbCalendar.removeAttr('aria-activedescendant');
				// self.tbCalendarYM.text( self.curYearMonth );
				self.tbCalendarYear.text(self.curYear);
				self.tbCalendarMonth.text(self.curMonth);

				// 포커스 이동
				if(self.btnName != '' || self.btnName != 'move') {
					setTimeout(function() {
						self.cal.find(self.btnName).focus();
					}, 5);
				}
				
				// 데이 붙이기
				self.addDayHandler();
			};

			UI_Cal.Datepicker.initialize.prototype.addDayHandler = function() {
				var self = this;
				// 데이 초기화(삭제)
				self.tbCalendar.find('tbody').empty();

				// 데이 붙이기
				var doMonth = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), 1]),
					lastDate = self.getCurDate([self.today.getFullYear(), self.today.getMonth() + 1, 0]),
					count = 0,
					lastCount = 0,
					len = 6,
					// len = Math.ceil( (doMonth.getDay() + lastDate.getDate())/7 ),
					startDate = null,
					startDateArr = null,
					startDateCompare = null,
					isYear = null,
					isMonth = null,
					isDay = null,
					chkDay = null;

				// 현재 날짜 보다 적을 경우 이전 월, 년도 선택 안되록 함
				var $todayGT = (self.getCurDate([self.today.getFullYear(), self.today.getMonth(), 1])).getTime();
				var $dateGT = (self.getCurDate([self.date.getFullYear(), self.date.getMonth(), self.date.getDate()])).getTime();
				var $realTodayGT = (self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), self.realToday.getDate()])).getTime();
				var $maxDateGT = (self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth() + 3, self.realToday.getDate() - 1])).getTime();

				var $lastMonthGT = (new Date(self.realToday.getFullYear(), self.realToday.getMonth() + 4, 0));
				var $minMonth = (self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), 1]));
				var $maxMonth = (self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth() + 3, 1]));
				var chkTodayMonth = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), 1]);
				var chkRealTodayMonth = self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), 1]);
				var chkRealMonth = self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth() - 11, 1]);

				var $lastDate = (new Date(self.realToday.getFullYear(), self.realToday.getMonth() + 4, self.realToday.getDate() - 1));
				if($maxDateGT > $lastMonthGT) $maxDateGT = $lastMonthGT;

				if(self.opt.beforeSelect == false) {
					if($todayGT <= $realTodayGT) {
						self.cal.find('.datepicker-month-fast-prev').addClass('disabled').attr('disabled', '');
						self.cal.find('.datepicker-month-prev').addClass('disabled').attr('disabled', '');
					} else {
						self.cal.find('.datepicker-month-fast-prev').removeClass('disabled').removeAttr('disabled');
						self.cal.find('.datepicker-month-prev').removeClass('disabled').removeAttr('disabled');
					}
					// 오늘 날짜 선택 안되도록
					// console.log('$today = ', ([self.today.getFullYear(), self.today.getMonth(), 1]), ' : $minMonth = ', [self.realToday.getFullYear(), self.realToday.getMonth(), 1], ': $maxMonth = ', [self.realToday.getFullYear(), self.realToday.getMonth() + 3, 1]);

					if(!self.opt.todaySelect) {
						self.cal.find('.datepicker-month-fast-next').addClass('disabled').attr('disabled', true);
						self.cal.find('.datepicker-month-fast-prev').addClass('disabled').attr('disabled', true);

						if($todayGT <= $minMonth.getTime()) {
							self.cal.find('.datepicker-month-prev').addClass('disabled').attr('disabled', true);
						} else {
							self.cal.find('.datepicker-month-prev').removeClass('disabled').removeAttr('disabled');
						}
						if($todayGT >= $maxMonth.getTime()) {
							self.cal.find('.datepicker-month-next').addClass('disabled').attr('disabled', true);
						} else {
							self.cal.find('.datepicker-month-next').removeClass('disabled').removeAttr('disabled');
						}
						self.cal.find('table thead').before(UI_Cal.Datepicker.captionEl);
					}
				}

				if(self.opt.afterSelect == false) {
					if(chkTodayMonth >= chkRealTodayMonth) {
						self.cal.find('.datepicker-month-next').addClass('disabled').attr('disabled', '');
					} else {
						self.cal.find('.datepicker-month-next').removeClass('disabled').removeAttr('disabled');
					}

					self.cal.find('.datepicker-month-fast-next').addClass('disabled').attr('disabled', '');

					if(chkTodayMonth >= chkRealMonth) {
						self.cal.find('.datepicker-month-fast-next').addClass('disabled').attr('disabled', '');
					} else {
						self.cal.find('.datepicker-month-fast-next').removeClass('disabled').removeAttr('disabled', '');
					}
				}

				if(self.fromToBtnName == 'to') {
					if($todayGT < $dateGT) {
						self.cal.find('.datepicker-month-fast-prev').addClass('disabled').attr('disabled', '');
						self.cal.find('.datepicker-month-prev').addClass('disabled').attr('disabled', '');
					} else {
						self.cal.find('.datepicker-month-fast-prev').removeClass('disabled').removeAttr('disabled');
						self.cal.find('.datepicker-month-prev').removeClass('disabled').removeAttr('disabled');
					}
				}

				

				if(self.btnName != '' || self.btnName != 'move' || self.btnName != null) {
					setTimeout(function() {
						self.cal.find(self.btnName).focus();
					}, 5);
				}

				

				// tr 붙이기
				for(var a = 0; a < len; a++) {
					self.tbCalendar.find('tbody').append('<tr id="row' + a + '-date" data-line="' + a + '"></tr>');
				}
				// from ~ to daysGap 추가
				if(self.opt.fromToTarget != null) {
					startDate = $(self.opt.fromToTarget).val();
					if(startDate.length == 10) {
						startDateArr = startDate.split(self.splitDate('point'));
						isYear = parseFloat(startDateArr[0]);
						isMonth = parseFloat(startDateArr[1]);
						isDay = parseFloat(startDateArr[2]);
						if($(self.opt.fromToTarget).is('.from-day')) {
							// 오픈된 캘린더가 .to-day였을 경우
							self.numCheck(startDateArr);
							if(self.numCheck([isYear, isMonth, isDay])) {
								self.gapDate = self.getCurDate([isYear, isMonth - 1, isDay + parseFloat(self.opt.daysGap) - 1]);
							}
						}
					}
				}

				// td 붙이기
				for(var a = 0; a < len * 7; a++) {
					var divideNum = Math.floor(a / 7),
						eqNum = a % 7;
					if(a < doMonth.getDay()) {
						// 이전달 뒷쪽 일
						self.tbCalendar.find('tbody tr').eq(0).append(UI_Cal.Datepicker.dayEmpty);
						var prevText = parseFloat((self.getCurDate([self.today.getFullYear(), self.today.getMonth(), 0])).getDate()),
							prevBlank = parseFloat(doMonth.getDay()) - (a + 1),
							rltText = prevText - prevBlank;
						self.tbCalendar.find('tbody tr').eq(0).find('td').eq(a).find('.day-txt').text(rltText);
					} else if(a >= doMonth.getDay() && a < lastDate.getDate() + doMonth.getDay()) {
						count++;
						self.tbCalendar.find('tbody tr').eq(divideNum).append(UI_Cal.Datepicker.dayAddTd);
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').html(count+'<span class="ui-blind">일</span>');
						// self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('title', self.curYearMonth + ' ' + count + self.opt.dayText + ' 선택 가능 버튼');
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').attr('title', self.curYearMonth + ' ' + count + self.opt.dayText + ' 선택');
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check', self.curYearMonth + ' ' + count + self.opt.dayText);
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('header', 'day' + eqNum + '-header-date');
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('id', 'cell' + count + '-' + self.id);
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-value', count);
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').attr('data-value', count);

						// 토요일
						if(eqNum == 6) {
							self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('saturday color');
							if(!self.opt.weekendClickable) {
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').addClass('disabled').attr('disabled',true).attr('title', chkDate+' 선택');
							}
						}
						// 일요일
						if(eqNum == 0) {
							self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('sunday color');
							if(!self.opt.weekendClickable) {
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').addClass('disabled').attr('disabled',true).attr('title', chkDate + ' 선택');
							}
						}

						// 오늘 날짜 배경 컬러
						var todayGetTime = (self.getCurDate([self.today.getFullYear(), self.today.getMonth(), count])).getTime();
						var dateGetTime = (self.getCurDate([self.date.getFullYear(), self.date.getMonth(), self.date.getDate()])).getTime();
						var realTodayGetTime = (self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), self.realToday.getDate()])).getTime();

						if(todayGetTime == realTodayGetTime) {
							chkDay = count;
							self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('today').append(UI_Cal.Datepicker.todayAdd);
							var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
							if(!self.opt.todaySelect) self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
							if(!self.opt.todaySelect) self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
						}

						// 이전 날짜 선택 안되게 함
						if(self.opt.beforeSelect == false) {
							if(todayGetTime < realTodayGetTime) {
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
								// 토요일
								if(eqNum == 6) {
									self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
								}
								// 일요일
								if(eqNum == 0) {
									self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
								}
							}
						}

						// 이후 날짜 선택 안되게 함
						if(self.opt.afterSelect == false) {
							if(todayGetTime > realTodayGetTime) {
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
								// 토요일
								if(eqNum == 6) {
									self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
								}
								// 일요일
								if(eqNum == 0) {
									self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
								}
							}
						}

						if(self.target.attr('data-fromdate') != null) {
							var fromDateArr = self.target.attr('data-fromdate').split(self.splitDate('point'));
							var fromGetTime = (self.getCurDate([fromDateArr[0], (parseInt(fromDateArr[1]) - 1), fromDateArr[2]])).getTime();
						}
						if(self.target.hasClass('to-day')) {
							if(self.target.attr('data-date') != null) {
								if(self.target.attr('data-fromdate') != null) {
									if(self.opt.isKeyboard == 'Keyboard' && self.target.val().length) {
										if(todayGetTime >= fromGetTime && todayGetTime <= dateGetTime) {
											self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('middle-day');
											if(todayGetTime == fromGetTime) {
												self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('from-day').removeClass('middle-day');
											}
											if(todayGetTime == dateGetTime) {
												self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('to-day').removeClass('middle-day');
											}
										}
									}
								}
							}
						}

						if(self.target.hasClass('to-day')) {
							if(self.target.attr('data-fromdate') != null) {
								if(self.opt.isKeyboard == 'Keyboard') {
									if(todayGetTime < fromGetTime) {
										var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
										self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
										self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
										// 토요일
										if(eqNum == 6) {
											self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
										}
										// 일요일
										if(eqNum == 0) {
											self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('color');
										}
									}
								}
							}
						}

						// from ~ to
						if(self.fromToBtnName == 'to') {
							if(todayGetTime < dateGetTime) {
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
							}
						}

						/* 20221121 : 추가 */
						// 대량이체예약
						if( self.opt.type == 'RV' ){
							var RVDayArray = [...self.opt.RVDayArray];
							var RVDayCheck = 0;

							RVDayArray.forEach(function(v,i){
								if(new Date(v).getTime() == todayGetTime){
									RVDayCheck++;
								}
							});
	
							if(! RVDayCheck ){
								var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled');
								self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
							} 
						}
						/* //20221121 : 추가 */

						// 오늘 년, 월 과 이동 년, 월이 같을때
						var target = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum);
						// target.attr('aria-selected', 'false').attr('tabindex', '-1').removeClass('select-day focus');
						// target.removeClass('select-day focus');
						if(self.btnName == '' || self.btnName == 'move' || self.btnName == null) {
							target.find('.day-txt').focus();
						}

						if(self.today.getFullYear() == self.date.getFullYear() && self.today.getMonth() == self.date.getMonth()) {
							// 첫 진입시
							if(self.opt.isKeyboard == null || self.opt.isKeyboard == undefined) {
								target.removeClass('select-day from-day to-day middle-day');
								if(count == parseFloat(self.date.getDate())) {
									if(self.target.val() == '') {
										// target.attr('tabindex', '0');
									} else {
										// target.attr('aria-selected', 'true').attr('tabindex', '0').addClass('select-day focus');
										target.addClass('select-day focus');
										// target.find('.day-txt').focus();
									}
									if(self.btnName == 'move') {
										// target.focus();
										target.find('.day-txt').focus();
									}
								}
							}
							// 키보드 이동시 'Keyboard'
							else if(self.opt.isKeyboard == 'Keyboard') {

								// 오늘 날짜
								if(count == self.date.getDate()) {
									if(self.target.val() == '') {
										// target.attr('tabindex', '0').addClass('focus');
										target.addClass('focus');
										// target.find('.day-txt').focus();
									} else {
										if(self.today.getFullYear() == self.selectToday.getFullYear() && self.today.getMonth() == self.selectToday.getMonth()) {
											// target.attr('aria-selected', 'true').attr('tabindex', '0').addClass('select-day focus');
											target.addClass('select-day focus');
											// target.find('.day-txt').focus();
										}
									}
									if(self.target.hasClass('selected-day')) {
										target.addClass('select-day');
									}
									// target.addClass('focus').attr('tabindex', '0');
									target.addClass('focus');
									// target.find('.day-txt').focus();
								}

								// 키보드 이동시 오늘 날짜 포커스
								if(count == self.today.getDate()) {
									// if(self.btnName == 'move') {
									// target.focus();
									// target.find('.day-txt').focus();
									// }
								}
							}
							// 3개월까지만 선택 되도록
							if(!self.opt.todaySelect) {
								if(todayGetTime > $maxDateGT) {
									var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
									target.removeClass('select-day focus').addClass('disabled');
									target.removeClass('select-day focus').addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택');
								}
							}
							// 오늘 년, 월 과 이동 년, 월이 다를때
						} else {
							if(self.opt.isKeyboard == 'Keyboard') {

								if(self.today.getFullYear() == self.selectToday.getFullYear() && self.today.getMonth() == self.selectToday.getMonth()) {
									if(count == self.selectToday.getDate()) {
										// target.addClass('select-day focus').attr('tabindex', '0').focus();
										if(self.btnName == '' || self.btnName == 'move' || self.btnName == null) {
											target.addClass('select-day focus').find('.day-txt').focus();
										}
									}
								} else {
									// self.tbCalendar.find('.day').eq(self.today.getDate() - 1).attr('tabindex', '0');
									self.tbCalendar.find('.day').eq(self.today.getDate() - 1);
									if(self.btnName == 'move') {
										// self.tbCalendar.find('.day').eq(self.today.getDate() - 1).focus();
										if(self.btnName == '' || self.btnName == 'move' || self.btnName == null) {
											self.tbCalendar.find('.day').eq(self.today.getDate() - 1).find('.day-txt').focus();
										}
									}
									if(todayGetTime == realTodayGetTime) {
										// self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('focus').attr('tabindex', '-1');
										self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).removeClass('focus');
									}
								}
								// 3개월까지만 선택 되도록
								if(!self.opt.todaySelect) {
									if(todayGetTime > $maxDateGT) {
										var chkDate = self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).attr('data-date-check');
										target.removeClass('select-day focus').addClass('disabled');
										target.removeClass('select-day focus').addClass('disabled').find('.day-txt').attr('disabled',true).attr('title', chkDate + ' 선택 불가능 버튼');
									}
								}
							} else if(self.opt.isKeyboard == null) {
								// from ~ to
								if(self.opt.fromToTarget != null) {
									if(isYear != null && isMonth != null && isDay != null && isYear != NaN && isMonth != NaN && isDay != NaN) {
										startDateCompare = self.getCurDate([isYear, isMonth - 1, isDay]);
										if(self.target.val().length == 10) {
											startDateArr = self.target.val().split(isPoint);
											if(self.numCheck(startDateArr)) {
												if(count == 1) {
													// self.tbCalendar.find('tbody tr').eq(0).find('td').eq(eqNum).addClass('focus').attr('tabindex', '0');
													self.tbCalendar.find('tbody tr').eq(0).find('td').eq(eqNum).addClass('focus');
													if(self.btnName == 'move') {
														// self.tbCalendar.find('tbody tr').eq(0).find('td').eq(eqNum).focus();
														if(self.btnName == '' || self.btnName == 'move' || self.btnName == null) {
															self.tbCalendar.find('tbody tr').eq(0).find('td').eq(eqNum).find('.day-txt').focus();
														}
													}
												}
											}
										} else {
											if(count == startDateCompare.getDate()) {
												// self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('focus').attr('tabindex', '0');
												self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).addClass('focus');
												if(self.btnName == 'move') {
													// self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).focus();
													if(self.btnName == '' || self.btnName == 'move' || self.btnName == null) {
														self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(eqNum).find('.day-txt').focus();
													}
												}
											}
										}
									}
								}
							}
						}
					} else {
						// 다음달 양쪽 일
						lastCount++;
						self.tbCalendar.find('tbody tr').eq(divideNum).append(UI_Cal.Datepicker.dayEmpty);
						self.tbCalendar.find('tbody tr').eq(divideNum).find('td').eq(a % 7).find('.day-txt').text(lastCount);
					}
				}
				self.cal.find('tbody').find('td.selectable').not('.disabled').eq(0).addClass('focus');
				if(self.today.getFullYear() == self.selectToday.getFullYear() && self.today.getMonth() == self.selectToday.getMonth()) {
					if(self.cal.find('tbody').find('td.selectable.select-day').length) {
						self.cal.find('tbody').find('td.selectable').not('.select-day').removeClass('focus');
					}
				}
				self.btnClickHandler();
			};

			// 버튼
			UI_Cal.Datepicker.initialize.prototype.btnClickHandler = function() {
				var self = this;
				/* // 데이 클릭
				self.tbCalendar.find('.day').not('.disabled, .disabled-over').off('click').on('click', function(e) {
					resultDateFn.selDate($(this));
					if(self.prevVal != self.target.val()) {
						self.target.trigger('change');
						self.opt.isKeyboard = 'Keyboard';
						if(self.opt.selectDayFn != null) {
							self.opt.selectDayFn(self.replaceAll(self.target.val(), '-', '.'));
						}
					}
					if(self.target.hasClass('to-day')) {
						self.target.attr('data-todate', self.target.attr('data-date'));
						self.addCalendar();
					}
				});

				// 데이 불가능
				self.tbCalendar.find('.day.disabled').off('click').on('click', function(e) {
					// self.tbCalendar.find('.day.select-day').focus();
					self.tbCalendar.find('.day.select-day').find('.day-txt').focus();
				});

				// 데이 오버 불가능
				self.tbCalendar.find('.day.disabled-over').off('click').on('click', function(e) {
					self.opt.toDateOverFn();
					// self.tbCalendar.find('.day.select-day').focus();
					self.tbCalendar.find('.day.select-day').find('.day-txt').focus();
				}); */

				// 데이 클릭
				self.tbCalendar.find('.day').not('.disabled, .disabled-over').find('.day-txt').off('click').on('click', function(e) {
					
					resultDateFn.selDate($(this).parent());
					self.tbCalendar.find('.day').find('.day-txt').attr('data-select', '');
					var txt = (self.tbCalendar.find('.day').find('.day-txt').attr('title')).replace(' 선택됨','');
					self.tbCalendar.find('.day').find('.day-txt').attr('title', txt);
					$(this).attr('data-select', ' 선택됨');
					var tit = $(this).attr('title').replace(' 선택됨','');
					$(this).attr('title', tit + $(this).attr('data-select'));

					if(self.prevVal != self.target.val()) {
						// self.target.trigger('change');
						self.opt.isKeyboard = 'Keyboard';
						if(self.opt.selectDayFn != null) {
							self.opt.selectDayFn(self.replaceAll(self.target.val(), '-', '.'));
						}
					}
					/* if(self.target.hasClass('to-day')) {
						self.target.attr('data-todate', self.target.attr('data-date'));
						// self.addCalendar();
					} */
					/* resultDateFn.selDate($(this));
					if(self.prevVal != self.target.val()) {
						self.target.trigger('change');
						self.opt.isKeyboard = 'Keyboard';
						if(self.opt.selectDayFn != null) {
							self.opt.selectDayFn(self.replaceAll(self.target.val(), '-', '.'));
						}
					}
					if(self.target.hasClass('to-day')) {
						self.target.attr('data-todate', self.target.attr('data-date'));
						self.addCalendar();
					} */
				});

				// 데이 불가능
				self.tbCalendar.find('.day.disabled').off('click').on('click', function(e) {
					// self.tbCalendar.find('.day.select-day').focus();
					self.tbCalendar.find('.day.select-day').find('.day-txt').focus();
				});

				// 데이 오버 불가능
				self.tbCalendar.find('.day.disabled-over').off('click').on('click', function(e) {
					self.opt.toDateOverFn();
					// self.tbCalendar.find('.day.select-day').focus();
					self.tbCalendar.find('.day.select-day').find('.day-txt').focus();
				});

				var targetVal = self.tbCalendar.find('.day.focus').attr('data-value');

				// 데이 키보드 엔터, 뱡향키
				/* self.tbCalendar.find('.day .day-txt').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						targetVal = parseFloat($(this).attr('data-value'));
						if(e.keyCode == '37') { // left
							self.btnName = 'move';
							resultDateFn.dateResult({curDay : targetVal, gapDay : -1});
						} else if(e.keyCode == '38') { // up
							self.btnName = 'move';
							resultDateFn.dateResult({curDay : targetVal, gapDay : -7});
						} else if(e.keyCode == '39') { // right
							self.btnName = 'move';
							resultDateFn.dateResult({curDay : targetVal, gapDay : 1});
						} else if(e.keyCode == '40') { // down
							self.btnName = 'move';
							resultDateFn.dateResult({curDay : targetVal, gapDay : 7});
						} else if(e.keyCode == '32') { // space
							if(!$(this).hasClass('disabled')) {
								resultDateFn.selDate($(this));
								self.target.addClass('selected-day');
							}
						} elseif(e.keyCode == '13') { // enter
							if(!$(this).hasClass('disabled')) {
								$(this).trigger('click');
								// resultDateFn.selDate($(this));
                                // self.target.addClass('selected-day');
							}
						}
					}
				}); */

				self.cal.on('focusin', function() {
					$('body').off('keydown').on('keydown', function(e) {
						if(e.keyCode == '38' || e.keyCode == '40') {
							e.preventDefault();
						}
						$('body').off('keydown');
					});

				});

				// 월 키보드 엔터
				self.tbCalendar.find('.month').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						targetVal = parseFloat($(this).attr('data-value'));
						/*if(e.keyCode == '37') { // left
							self.btnName = 'move';
							if(self.moveMonthHandler(-1)) {
								self.tbCalendar.find('td').off();
								this.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
						} else if(e.keyCode == '38') { // up
							self.btnName = 'move';
							if(self.moveMonthHandler(-4)) {
								self.tbCalendar.find('td').off();
								this.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
						} else if(e.keyCode == '39') { // right
							self.btnName = 'move';
							if(self.moveMonthHandler(1)) {
								self.tbCalendar.find('td').off();
								this.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
						} else if(e.keyCode == '40') { // down
							self.btnName = 'move';
							if(self.moveMonthHandler(4)) {
								self.tbCalendar.find('td').off();
								this.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
						} else if(e.keyCode == '32') { // space
							resultDateFn.selMonth($(this));
						} else */if(e.keyCode == '13') { // enter
							resultDateFn.selMonth($(this));
						}
					}
				});

				// 캘린더 닫기
				self.cal.find('.datepicker-close').off('click').on('click', function(e) {
					self.target.next('a, button').attr('aria-expanded', 'false');
					self.cal.css('display', 'none').attr('aria-hidden', 'true');
					if(self.calbg != null) self.calbg.css('display', 'none');
					$('body').removeClass('show-calendar');
					self.btnName = null;
					if(self.opt.ariaHiddenArea != null) {
						if(typeof self.opt.ariaHiddenArea == 'object') {
							for(var a = 0; a < self.opt.ariaHiddenArea.length; a++) {
								$(self.opt.ariaHiddenArea[a]).attr('aria-hidden', 'false');
							}

						} else if(typeof self.opt.ariaHiddenArea == 'string') {
							$(self.opt.ariaHiddenArea).attr('aria-hidden', 'false');
						}
					}

					// self.target.focus();
					self.target.find('.day-txt').focus();
					setTimeout(function() {
						if(self.mobile != null) {
							self.target.blur();
						}
					}, 10);

					var isPoint = self.splitDate('point');
					// from ~ to
					if($(self.opt.fromToTarget).is('.to-day')) {
						var endDate = null,
							endDateArr = null,
							endDateCompare = null,
							startDateCompare = null,
							startDateArr = null,
							isYear = null,
							isMonth = null,
							isDay = null;
						// from ~ to 일때
						if(self.opt.fromToTarget != null) {
							endDate = $(self.opt.fromToTarget).val();
							if(endDate.length == 10) {
								endDateArr = endDate.split(isPoint);
								isYear = parseFloat(endDateArr[0]);
								isMonth = parseFloat(endDateArr[1]);
								isDay = parseFloat(endDateArr[2]);

								if(self.numCheck(endDateArr)) {
									endDateCompare = self.getCurDate([isYear, isMonth - 1, isDay]);
									if(self.target.val().length == 10) {
										startDateArr = self.target.val().split(isPoint);
										var startYear = parseFloat(startDateArr[0]),
											startMonth = parseFloat(startDateArr[1]),
											startDay = parseFloat(startDateArr[2]);
										if(self.numCheck(startDateArr)) {
											startDateCompare = self.getCurDate([startYear, startMonth - 1, startDay]);
											if(endDateCompare.getTime() < startDateCompare.getTime()) {
												$(self.opt.fromToTarget).val(self.target.val());
											}
										}
									}
								}
							}
						}
					}
				});

				// year, month    SELECT일 경우
				if(self.opt.selectBool) {
					self.cal.find('.calendar-year-select').off('change').on('change', function(e) {
						self.btnName = '.calendar-year-select';
						var value = parseFloat($(this).val());
						var resultNum = parseFloat(self.today.getFullYear()) - value;
						resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : resultNum * -12});
					});
					self.cal.find('.calendar-month-select').off('change').on('change', function(e) {
						self.btnName = '.calendar-month-select';
						var value = parseFloat($(this).val());
						var resultNum = value - parseFloat(self.today.getMonth() + 1);
						resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : resultNum});
					});
				}

				// 이전년도 마우스 클릭
				self.cal.find('.datepicker-month-fast-prev').off('click').on('click', function(e) {
					self.btnName = '.datepicker-month-fast-prev';
					resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : -12});
				});

				// 이전년도 키보드 엔터
				self.cal.find('.datepicker-month-fast-prev').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						if(e.keyCode === '32' || e.keyCode == '13') {
							self.btnName = '.datepicker-month-fast-prev';
							resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : -12});
						}
					}
				});

				// 다음년도 마우스 클릭
				self.cal.find('.datepicker-month-fast-next').off('click').on('click', function(e) {
					self.btnName = '.datepicker-month-fast-next';
					resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : 12});
				});

				// 다음년도 키보드 엔터
				/* self.cal.find('.datepicker-month-fast-next').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						if(e.keyCode === '32' || e.keyCode == '13') {
							self.btnName = '.datepicker-month-fast-next';
							resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : 12});
						}
					}
				}); */

				// 이전달 마우스 클릭
				self.cal.find('.datepicker-month-prev').off('click').on('click', function(e) {
					self.btnName = '.datepicker-month-prev';
					resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : -1});
				});

				// 이전달 키보드 엔터
				/* self.cal.find('.datepicker-month-prev').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						if(e.keyCode === '32' || e.keyCode == '13') {
							self.btnName = '.datepicker-month-prev';
							resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : -1});
						}
					}
				});
 */
				// 다음달 마우스 클릭
				self.cal.find('.datepicker-month-next').off('click').on('click', function(e) {
					self.btnName = '.datepicker-month-next';
					resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : 1});
				});

				// 다음달 키보드 엔터
				/* self.cal.find('.datepicker-month-next').off('keydown').on('keydown', function(e) {
					if($(this).focusin()) {
						if(e.keyCode === '32' || e.keyCode == '13') {
							self.btnName = '.datepicker-month-next';
							resultDateFn.dateResult({curMonth : self.today.getMonth(), gapMonth : 1});
						}
					}
				}); */

				// 오늘 날짜 버튼
				self.cal.find('.datepicker-today').off('click keydown').on('click keydown', function(e) {
					if(e.type == 'click') {
						self.btnName = '.datepicker-today';
						self.today = self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), self.realToday.getDate()]);
						self.tbCalendar.find('td').off();
						self.opt.isKeyboard = 'Keyboard';
						self.addCalendar();
					}/*  else if(e.type == 'keydown') {
						if($(this).focusin()) {
							if(e.keyCode === '32' || e.keyCode == '13') {
								self.btnName = '.datepicker-today';
							}
						}
					} */
				});

				// 마우스 이동 및 클릭, 키보드 이동 및 엔터
				var resultDateFn = {
					dateResult : function(options) {
						var obj = {
							curDay : null,
							gapDay : -1,
							curMonth : null,
							gapMonth : -1
						};
						var thisOpt = $.extend({}, obj, options),
							dayCalc = (thisOpt.curDay != null) ? thisOpt.curDay + thisOpt.gapDay : null,
							monthCalc = (thisOpt.curMonth != null) ? thisOpt.curMonth + thisOpt.gapMonth : null,
							moveDay = null,
							firstDate = null,
							moveMonth = null;
						// ================
						// move day
						// ================
						if(dayCalc != null && monthCalc == null) {
							moveDay = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), dayCalc, 0, 0]);
							// from ~ to
							if(self.opt.fromToTarget != null && $(self.opt.fromToTarget).is('.from-day')) {
								var startDate = $(self.opt.fromToTarget).val();

								if(startDate.length == 10) {
									var startDateArr = startDate.split(self.splitDate('point'));
									if(startDateArr.length == 3) {
										if(self.numCheck(startDateArr)) {
											firstDate = self.getCurDate([parseFloat(startDateArr[0]), parseFloat(startDateArr[1]) - 1, parseFloat(startDateArr[2]), 0, 0]);
											if(moveDay.getTime() >= firstDate.getTime()) {

												self.today = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), dayCalc]);
												if(self.gapDate.getTime() < moveDay.getTime()) {
												} else {
													self.tbCalendar.find('td').off();
													self.opt.isKeyboard = 'Keyboard';
													self.addCalendar();
												}
											} else {
											}
										}
									}
								} else {
									self.today = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), dayCalc]);
									self.tbCalendar.find('td').off();
									self.opt.isKeyboard = 'Keyboard';
									self.addCalendar();
								}
								// 오늘 날짜 보다 이전날짜 선택 불가능 버튼
							} else if(!self.opt.beforeSelect) {
								var realTodayGetTime = self.getCurDate([self.realToday.getFullYear(), self.realToday.getMonth(), self.realToday.getDate() + 1, 0, 0]);
								var $lastDate = (new Date(self.realToday.getFullYear(), self.realToday.getMonth() + 3, self.realToday.getDate() - 1));

								// 이전 날짜 선택 안되도록 할때
								if(moveDay.getTime() < realTodayGetTime.getTime()) {
									dayCalc = thisOpt.curDay;
								}
								// 3개월 이후 날짜 선택 안되도록 할때
								if(moveDay.getTime() > $lastDate.getTime()) {
									dayCalc = thisOpt.curDay;
								}
								self.today = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), dayCalc]);
								self.tbCalendar.find('td').off();
								self.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							} else {
								self.today = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), dayCalc]);

								if(self.opt.afterSelect == false) {
									if(self.today.getTime() > self.date.getTime()) {
										self.today = self.date;
									}
								}
								self.tbCalendar.find('td').off();
								self.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
							// ===================
							// move month(year)
							// ===================
						} else if(dayCalc == null && monthCalc != null) {
							moveMonth = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
							// from ~ to
							if(self.opt.fromToTarget != null && $(self.opt.fromToTarget).is('.from-day')) {
								var startDate = $(self.opt.fromToTarget).val();
								var startDateArr = null;

								if((self.date.getFullYear() == moveMonth.getFullYear() && self.date.getMonth() == monthCalc)) {
									moveMonth = self.getCurDate([self.today.getFullYear(), self.date.getMonth(), self.date.getDate()]);
								}
								// from-day에 값이 있을 때
								if(startDate.length == 10) {
									startDateArr = startDate.split(self.splitDate('point'));
									if(startDateArr.length == 3) {
										if(self.numCheck(startDateArr)) {
											firstDate = self.getCurDate([parseFloat(startDateArr[0]), parseFloat(startDateArr[1]) - 1, parseFloat(startDateArr[2])]);
											if(moveMonth.getTime() >= firstDate.getTime()) {
												if(moveMonth.getTime() <= self.date.getTime()) {
													self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
												} else {
													// daysGap 추가
													self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
													if(self.opt.daysGap != null) {

														if(self.today.getTime() > self.gapDate.getTime()) {
															self.today = self.gapDate;
														} else {
														}
													} else {
													}
												}
												self.tbCalendar.find('td').off();
												self.opt.isKeyboard = 'Keyboard';
												self.addCalendar();
											} else {
												if(moveMonth.getTime() <= firstDate.getTime()) {
													self.today = firstDate;
													self.date = firstDate;
													self.tbCalendar.find('td').off();
													self.opt.isKeyboard = null;
													self.addCalendar();
												}
											}
										}
									}
									// from-day에 값이 없을 때
								} else {
									if(self.today.getFullYear() == self.moveMonth.getFullYear() && self.today.getMonth() == monthCalc) {
										self.today = self.getCurDate([self.today.getFullYear(), self.date.getMonth(), self.date.getDate()]);
									} else {
										self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
									}
									self.tbCalendar.find('td').off();
									self.opt.isKeyboard = 'Keyboard';
									self.addCalendar();
								}
							}

							// 이전 날짜 선택 안되도록 할때
							if(!self.opt.beforeSelect) {
								self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
								self.tbCalendar.find('td').off();
								self.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							} else if(self.opt.beforeSelect) {
								var realMonthGetTime = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), self.selectToday.getDate(), 0, 0]);

								if(moveMonth.getTime() < realMonthGetTime.getTime()) {
									// target(input)에 값이 있을 경우
									var isDay = $(self.target).val() == '' ? self.selectToday.getDate() : self.date.getDate();
									//self.today = self.getCurDate([self.selectToday.getFullYear(), monthCalc, 1]);
									self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
								} else {
									self.today = self.getCurDate([self.today.getFullYear(), monthCalc, 1]);
								}
								self.tbCalendar.find('td').off();
								self.opt.isKeyboard = 'Keyboard';
								self.addCalendar();
							}
						}
					},
					selDate : function(day) {
						// day : 선택한 td
						var $this = day,
							otherDate = null,
							otherDateArr = null,
							otherDateCompare = null,
							selfDateCompare = null,
							selfGapDateCompare = null,
							isYear = null,
							isMonth = null,
							isDay = null;

						var selDateNum = null,
							selYear = self.today.getFullYear(),
							selMonth = self.numSet(self.today.getMonth() + 1),
							selDay = self.numSet(parseInt($this.attr('data-value')));
						if(self.opt.beforeSelect != false && self.opt.todaySelect != false) {
							self.today = self.getCurDate([self.today.getFullYear(), self.today.getMonth(), $this.attr('data-value')]);
							self.date = self.today;
						} else {
							self.selectToday = self.getCurDate([selYear, selMonth - 1, selDay]);
						}

						// 탭이동시 선택한 날짜만 포커스 이동되도록 함
						/* for(var a = 0; a < self.cal.find('tbody td').length; a++) {
							var tabindex = self.cal.find('tbody td').eq(a).attr('tabindex');
							if(tabindex == '-1' || tabindex == '0') {
								self.cal.find('tbody td').not('.empty').attr('tabindex', '-1');
							}
						} */
						// 선택한 날짜만 포커스 이동 되도록 수정
						// $this.attr('tabindex', '0');

						selDateNum = self.splitDate([selYear, selMonth, selDay]);
						if(self.opt.selectGap == 'half') {
							var selectGapDate = 0;
							if(selDay <= 15) selectGapDate = '01';
							else selectGapDate = '16';
							selDateNum = self.splitDate([selYear, selMonth, selectGapDate]);

							if(selDay <= 15) {
								if(self.opt.format == "yyyy-mm-dd") {
									self.target.val(selYear + '-' + selMonth + '-01 ~ ' + selYear + '-' + selMonth + '-15');
								} else if(self.opt.format == "yyyy.mm.dd") {
									self.target.val(selYear + '.' + selMonth + '.01 ~ ' + selYear + '.' + selMonth + '.15');
								}
							} else {
								var totalDate = (self.getCurDate([selYear, selMonth, 0])).getDate();
								if(self.opt.format == "yyyy-mm-dd") {
									self.target.val(selYear + '-' + selMonth + '-16 ~ ' + selYear + '-' + selMonth + '-' + totalDate);
								} else if(self.opt.format == "yyyy.mm.dd") {
									self.target.val(selYear + '.' + selMonth + '.16 ~ ' + selYear + '.' + selMonth + '.' + totalDate);
								}
							}
							self.target.attr('data-date', self.target.val());
						} else {
							self.target.attr('data-date', selDateNum);
							self.target.val(selDateNum);    
							$(`#${self.target.data('target')}`).val(selDateNum);  //220920  
						}

						var isPoint = self.splitDate('point');
						// from ~ to
						if(self.opt.fromToTarget != null) {
							if(self.opt.daysGap == null) {
								otherDate = $(self.opt.fromToTarget).val();
								otherDateArr = otherDate.split(isPoint);
								if(otherDate.length == 10 && otherDateArr.length == 3) {
									if($(self.opt.fromToTarget).is('.to-day')) {
										// 펼쳐진 캘린더가 .from-day였을 경우
										if(self.numCheck(otherDateArr)) {
											isYear = parseFloat(otherDateArr[0]);
											isMonth = parseFloat(otherDateArr[1]);
											isDay = parseFloat(otherDateArr[2]);
											otherDateCompare = self.getCurDate([isYear, isMonth - 1, isDay]);
											selfDateCompare = self.getCurDate([selYear, selMonth - 1, selDay]);
											if(otherDateCompare.getTime() < selfDateCompare.getTime()) {
												$(self.opt.fromToTarget).val(selDateNum);
											}
										}
									}
								}
							} else {
								if($(self.opt.fromToTarget).is('.to-day')) {
									otherDate = $(self.opt.fromToTarget).val();
									otherDateArr = otherDate.split(isPoint);
									if(otherDate.length == 10 && otherDateArr.length == 3) {
										if(self.numCheck(otherDateArr)) {
											isYear = parseFloat(otherDateArr[0]);
											isMonth = parseFloat(otherDateArr[1]);
											isDay = parseFloat(otherDateArr[2]);
											otherDateCompare = self.getCurDate([isYear, isMonth - 1, isDay]);
											selfDateCompare = self.getCurDate([selYear, selMonth - 1, selDay]);
											selfGapDateCompare = self.getCurDate([selYear, selMonth - 1, parseFloat(selDay) + parseFloat(self.opt.daysGap) - 1]);

											if(otherDateCompare.getTime() > selfGapDateCompare.getTime()) {
												$(self.opt.fromToTarget).val(selDateNum);
											}
										}
									}
								}
							}
						}
						self.tbCalendar.find('.day').removeClass('select-day focus');
						// self.tbCalendar.find('.day').attr('aria-selected', 'false');

						// self.tbCalendar.find('.day').find('.day-txt');
						// $this.find('.day-txt').attr('aria-selected', 'true');

						// 날짜 선택시 닫힘
						if(self.opt.selectClose) {
							self.cal.find('.datepicker-close').trigger('click');
						} else {
							// $this.addClass('select-day focus').focus();
							$this.addClass('select-day focus').find('.day-txt').focus();
						}
					},
					selMonth : function(month) {
						var $this = month,
							selDateNum = null,
							selYear = self.today.getFullYear(),
							selMonth = self.numSet(parseFloat($this.attr('data-value')));
						selDateNum = self.splitDate([selYear, selMonth, '01']);
						self.today = self.getCurDate([self.today.getFullYear(), selMonth - 1, '01']);
						self.date = self.today;

						var chkDay = '';

						self.target.attr('data-date', selDateNum + chkDay);
						self.target.val(selDateNum);

						self.tbCalendar.find('.month').removeClass('cur-month focus');
						// self.tbCalendar.find('.month').attr('aria-selected', 'false');
						// $this.attr('aria-selected', 'true');

						if(self.opt.selectClose) {
							self.cal.find('.datepicker-close').trigger('click');
						} else {
							$this.addClass('cur-month focus').focus();
						}
					}
				};
			};
		},

		fromTo : function(options) {
			var self = this;
			this.opt = $.extend({}, UI_Cal.Datepicker.DEFAULTS, options);

			if(this.opt.fromTarget != null) {
				if(this.opt.toTarget != null) {
					$(this.opt.fromTarget).addClass('from-day');
					$(this.opt.fromTarget).next('.btn').addClass('from');
					$(this.opt.toTarget).addClass('to-day');
					$(this.opt.toTarget).next('.btn').addClass('to');

					if($(this.opt.fromTarget).is('.from-day')) {
						this.opt.fromToTarget = this.opt.toTarget;

						// from 캘린더 실행
						$(this.opt.fromTarget).uiCal(this.opt);

						// fromDate 값이 있을때
						if(this.opt.fromDate != null && this.opt.fromDate != 'today') {
							$(this.opt.fromTarget).val(this.opt.fromDate);
						}
						// fromDate 값이 'today' 일때
						if(this.opt.fromDate == 'today') {
							var today = new Date();
							var year = today.getFullYear(); // 년도
							var month = today.getMonth() + 1;  // 월
							var date = (today.getDate() < 10 ? '0' + today.getDate() : today.getDate());  // 날짜
							var day = today.getDay();  // 요일
							if(this.opt.format == "yyyy-mm-dd") {
								$(this.opt.fromTarget).val(year + '-' + month + '-' + date);
							} else {
								$(this.opt.fromTarget).val(year + '.' + month + '.' + date);
							}
						}

						// toDate 값이 있을때
						if(this.opt.toDate != null) {
							$(this.opt.toTarget).val(this.opt.toTarget);
						}
						// toDate 값이 'today' 일때
						if(this.opt.toDate == 'today') {
							var today = new Date();
							var year = today.getFullYear(); // 년도
							var month = today.getMonth() + 1;  // 월
							var date = (today.getDate() < 10 ? '0' + today.getDate() : today.getDate());  // 날짜
							var day = today.getDay();  // 요일
							if(this.opt.format == "yyyy-mm-dd") {
								$(this.opt.toTarget).val(year + '-' + month + '-' + date);
							} else {
								$(this.opt.toTarget).val(year + '.' + month + '.' + date);
							}
						}
					}
					if($(this.opt.toTarget).is('.to-day')) {
						this.opt.fromToTarget = this.opt.fromTarget;
						// to 캘린더 실행
						$(this.opt.toTarget).uiCal(this.opt);
					}
				} else {
				}
			} else {
			}
		}
	}
};

UI_Cal.Datepicker.common.prototypeInit();

/* 20221121 : 수정 */
$.fn.uiCal = function(options, callback) {
	var opt = $.extend({}, UI_Cal.Datepicker.DEFAULTS, options);
	return new UI_Cal.Datepicker.initialize($(this), opt, callback);
};
/* //20221121 : 수정 */

/* 20221121 : 삭제 */
// $(document).ready(function(){
// 	$('.ui-calendar').on('click',function(e){
// 		e.preventDefault();
// 	}); 
// });